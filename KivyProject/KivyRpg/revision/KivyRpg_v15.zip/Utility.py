#---------------------#
# custom log
#---------------------#
import sys
file = open("kivy_log.txt","w")
file.write("")
file.close()
class myLogger:
  def write(self, data):
    file = open("kivy_log.txt","a")
    file.write(data)
    file.close()
sys.stderr = myLogger()

#---------------------#
# use for c style pointer variable
#---------------------#
class Pointer:
  value = None
  
  def __init__(self, value):
    self.set(value)
  
  def set(self, value):
    self.value = value
    
  def get(self):
    return self.value

#---------------------#
# Import kivy
#---------------------#
import kivy
from kivy.app import App
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.core.audio import SoundLoader
from kivy.factory import Factory
from kivy.graphics import Color, Rectangle, Point, GraphicException, Line, Quad, Ellipse, Fbo, RenderContext
from kivy.graphics.instructions import Instruction
from kivy.graphics.opengl import glLineWidth
from kivy.logger import Logger
from kivy.properties import NumericProperty, ReferenceListProperty, ObjectProperty, StringProperty
from kivy.uix.screenmanager import ScreenManager, Screen, SlideTransition, SwapTransition, WipeTransition, FadeTransition
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.image import Image
from kivy.uix.label import Label
from kivy.uix.modalview import ModalView
from kivy.uix.popup import Popup
from kivy.uix.progressbar import ProgressBar
from kivy.uix.relativelayout import RelativeLayout
from kivy.uix.scatter import Scatter
from kivy.uix.scrollview import ScrollView
from kivy.uix.slider import Slider
from kivy.uix.textinput import TextInput
from kivy.uix.treeview import TreeView, TreeViewLabel
from kivy.uix.widget import Widget
from kivy.vector import Vector

#---------------------#
# Import library
#---------------------#
global isAndroid
isAndroid = False
try:
  import android
  isAndroid = True
except:
  isAndroid = False
import time
from cmath import polar, rect
from copy import copy, deepcopy
from glob import glob
import math
from math import cos,sin,pi,sqrt,atan,atan2
import os
from os import path
import random
import threading
import traceback 
from cStringIO import StringIO

#---------------------#
# Global Instance
#---------------------#
def setGlobalInstance():
  global gMyRoot, gDebug, log
  gMyRoot = MyRoot.instance()
  gDebug = DebugPrint.instance()
  log = gDebug.log
  
#---------------------#
# Global variable
#---------------------#
W = float(Window.size[0])
H = float(Window.size[1])
WW = (W,W)
HH = (H,H)
WH = (W, H)
WRatio = H/W
HRatio = W/H
cX = W * 0.5
cY = H * 0.5
cXY = (W * 0.5, H * 0.5)

def WRect(size):
  return mul(WH, (size, size*HRatio))

def HRect(size):
  return mul(WH, (size*WRatio, size))

fUpdateTime = 1.0 / 60.0
fFrameTime = 1.0
fAccTime = 0.0
bButtonLock = False

def add(A, B):
  if type(B) != tuple and type(B) != list:
    return [i+B for i in A]
  else:
    return [A[i]+B[i] for i in range(len(A))]

def sub(A, B):
  if type(B) != tuple and type(B) != list:
    return [i-B for i in A]
  else:
    return [A[i]-B[i] for i in range(len(A))]

def mul(A, B):
  if type(B) != tuple and type(B) != list:
    return [i*B for i in A]
  else:
    return [A[i]*B[i] for i in range(len(A))]

def div(A, B):
  if type(B) != tuple and type(B) != list:
    return [i/B for i in A]
  else:
    return [A[i]/B[i] for i in range(len(A))]

def dot(A, B):
 return sum(mul(A, B))
 
def getDist(A, B = None):
  temp = sub(A, B) if B else A
  return sqrt(sum([i*i for i in temp]))
  
def normalize(A, dist = None):
  if dist == None:
    dist = getDist(A)
  return div(A, dist) if dist > 0.0 else mul(A, 0.0)

def getFrameTime():
  return fFrameTime
  
def getAccTime():
  return fAccTime

def getHint(ratioX, ratioY, size = WH):
  return (size[0] * ratioX, size[1] * ratioY)
  
def getCenter(pos, size):
  return (pos[0] + size[0]*.5, pos[1] + size[1]*.5)

def getLT(center, size):
  return (center_pos[0]-size[0]/2.0, center_pos[1]+size[1]/2.0)

def getRT(center, size):
  return (center_pos[0]+size[0]/2.0, center_pos[1]+size[1]/2.0)

def getLB(center, size):
  return (center_pos[0]-size[0]/2.0, center_pos[1]-size[1]/2.0)

def getRB(center, size):
  return (center_pos[0]+size[0]/2.0, center_pos[1]-size[1]/2.0)
#---------------------#
# Utility
#---------------------#
def nRand(min, max):
  return random.randint(min, max)

def fRand(min, max):
  return random.uniform(min, max)

def calcCenterPos(pos, size):
  return (pos[0]+size[0]/2.0, center_pos[1]+size[1]/2.0)
     
def calcPos(center_pos, size):
  return (center_pos[0]-size[0]/2.0, center_pos[1]-size[1]/2.0)

def calcSize(size, ratioX, ratioY):
  return (size[0]*ratioX, size[1]*ratioY)

def getButton(text, center, size):
  widget = Button()
  widget.text = text
  widget.size = getHint( size[0], size[1], WH )
  widget.center = getHint( center[0], center[1], WH )
  return widget
  
#---------------------#
# CLASS : Singleton
#---------------------#
class Singleton:
  __instance = None
  
  @classmethod
  def getInstance(cls):
    return cls.__instance
    
  @classmethod
  def instance(cls, *args, **kargs):
    cls.__instance = cls(*args, **kargs)
    cls.instance = cls.getInstance
    return cls.__instance

#---------------------#
# CLASS : Var
#---------------------#
class Var:
  def __init__(self, v1=None, v2=None):
    if v1 == None:
      return
      
    self.min = v1
      
    if v2 != None:
      self.v1 = v1
      self.v2 = v2
      self.max = v2
      if type(v1) == list or type(v1) == tuple:
        self.get = self.getRandList
      else:
        self.get = self.getRandScalar
    else:
      self.v1 = v1
      self.max = v1
      if type(v1) == list or type(v1) == tuple:
        self.get = self.getList
      else:
        self.get = self.getScalar
    
  def setValue(self, v1=None, v2=None):
    self.__init__(v1, v2)
    
  def getMin(self):
    return self.min
  
  def getMax(self):
    return self.max

  def get(self):
    pass

  def getList(self):
    return copy(self.v1)

  def getScalar(self):
    return self.v1

  def getRandList(self):
    return [random.uniform(self.v1[i],self.v2[i]) for i in range(len(self.v1))]

  def getRandScalar(self):
    return random.uniform(self.v1, self.v2)

#---------------------#
# CLASS : jobObject
#---------------------#
class jobObject:
  def __init__(self, func, args=(), kargs={}):
    self.func = func
    self.args = args
    self.kargs = kargs
        
  def doJob(self):
    self.func(*self.args, **self.kargs)

#---------------------#
# CLASS : Job
#---------------------#
class Job:  
  def __init__(self, title):
    self.title = title
    self.jobList = []
    self.isFirstUpdate = True
      
  def addJob(self, func, args=(), kargs={}):
    self.jobList.append(jobObject(func, args, kargs))
      
  def update(self): 
    if self.isFirstUpdate:
      # show popup
      gMyRoot.createProgressPopup(self.title, 0)
      self.isFirstUpdate = False
    else:
      # do job
      while self.jobList:
        job = self.jobList.pop(0)
        job.doJob()
      # destroy popup
      gMyRoot.destroyProgressPopup()
       
  def isComplete(self):
    return self.jobList == []
      
#---------------------#
# CLASS : REPL
#---------------------#
class REPL(Singleton, TextInput):
  name = "Python REPL"
  result = ""
  code = []
  lastCode = ""
  myGlobals = {}
  insertPos = -1
  
  def __init__(self, pos, size):
    TextInput.__init__(self, text = "", multiline=False, size=size, pos=pos,
      background_color=(1,1,1,0.1), foreground_color=(1,1,1,1))
    self.bind(on_text_validate = lambda inst:self.onConsoleInput(inst.text))
    self.bind(focus = self._focus)
    
  def _focus(self, inst, value):
    if not value and self.text:
      self.text = ""
      self.focus=True
    else:
      self.focus=value
       
  def onConsoleInput(self, inputText):
    result = self.run_script(inputText)
    
    # insert input
    if inputText:
      if self.insertPos > 0:
        gDebug.log("  " + inputText, self.insertPos)
      else:
        gDebug.log("> " + inputText, self.insertPos)
        
    # insert result
    if result:
      self.insertPos += 1
      gDebug.log(result, self.insertPos)
      self.insertPos = -1
    elif inputText and self.code == []:
      self.insertPos = -1
    
    if self.lastCode:
      temp = self.lastCode
      self.lastCode = None
      self.onConsoleInput(temp)
      
  def run_script(self, code):
    self.insertPos += 1
    # run script
    if self.code and (code == "" or code[0] != " " and code[0] != "\t"):
      self.lastCode = code
      code = "\n".join(self.code)
      self.code = []
    # inner indent mode
    elif self.code or code and code.strip()[-1] == ":":
      self.code.append(code)
      return None
      
    try:
      self.old_stdout = sys.stdout
      self.redirected_output = sys.stdout = StringIO()
      try:
        print eval(code, self.myGlobals)
      except:
        exec(code, self.myGlobals)
        
      sys.stdout = self.old_stdout
      self.result = self.redirected_output.getvalue()
    except Exception, e:
      self.errorstring = traceback.format_exc()
      self.result = ("ERROR: " + self.errorstring)
    return self.result[:-1]
    
#---------------------#
# CLASS : DebugPrint
#---------------------#
class DebugPrint(Widget, Singleton):
  nLineLimit = 85
  curLineCount = 0
  staticLineCount = 0
  szString = ""
  szStatic = ""
  szOldString = ""
  bUpdate = False
  bShowFrame = True
  bShowUpdate = False
  checkFrameTime = 0.0
  lastFrameTime = 0.0
  frameCount = 0.0
  btn_width = W * 0.09
  btn_height = H * 0.08
  logBuffer = []
  bSaveLog = False
  debugLabelSizeHint = 3.0
  debugLabelSize = (W, H - btn_height)

  def __init__(self):
    Widget.__init__(self)
    
  def init(self): 
    # toggle btn
    self.fps = Button(text="Toggle", size=(self.btn_width, self.btn_height), pos=(0, H-self.btn_height))
    self.fps.bind(on_release = self.toggleDebug)
    self.fps.name = "FPS"
    self.add_widget(self.fps)
    
    self.btn_update = Button(text="Update", size=(self.btn_width, self.btn_height), pos=(self.btn_width, H-self.btn_height))
    self.btn_update.bind(on_release=self.toggleShowUpdate)
    self.add_widget(self.btn_update)
    
    self.btn_clear = Button(text="Clear", size=(self.btn_width, self.btn_height), pos=(self.btn_width*2, H-self.btn_height))
    self.btn_clear.bind(on_release = self.clearPrint)
    self.add_widget(self.btn_clear)
    
    self.btn_scroll = Button(text="Scroll", size=(self.btn_width, self.btn_height), pos=(self.btn_width*3, H-self.btn_height))
    self.btn_scroll.bind(on_release = self.toggleScroll)
    self.add_widget(self.btn_scroll)
    
    self.repl = REPL(size=(W * 0.5, self.btn_height), pos=(self.btn_width*4.0, H-self.btn_height))
    self.add_widget(self.repl)
    
    # label
    self.debugLabel = Label(text="", halign='left', valign='top', max_lines=self.nLineLimit, readonly=True,
      multiline=True, background_color=(1,1,1,0), foreground_color=(1,1,1,1), size_hint_y=None) 
    self.debugLabel.size = self.debugLabelSize
    self.debugLabel.text_size = self.debugLabel.size
    self.debugLabel.pos=(0,0)
    self.debugLabel.name = "Print output"
    self.add_widget(self.debugLabel)
    
    self.scroll = ScrollView(size_hint=(None, None), size=self.debugLabelSize, pos=(0,0))
    
    self.toggleDebug()
    
  def isScroll(self):
    return self.debugLabel.parent == self.scroll
  
  def toggleShowUpdate(self, *args):
    self.bShowUpdate = not self.bShowUpdate
    self.bUpdate = True
  
  def toggleScroll(self, *args):
    if self.isScroll():
      parent = self.scroll.parent
      self.scroll.remove_widget(self.debugLabel)
      if parent:
        parent.remove_widget(self.scroll)
        parent.add_widget(self.debugLabel)
      self.debugLabel.size = self.debugLabelSize
      self.debugLabel.text_size = self.debugLabel.size
    else:
      parent = self.debugLabel.parent
      if parent:
        parent.add_widget(self.scroll)
        parent.remove_widget(self.debugLabel)
      self.scroll.add_widget(self.debugLabel)
      self.debugLabel.size = (W, H*self.debugLabelSizeHint)
      self.debugLabel.text_size = self.debugLabel.size
    
  def toggleDebug(self, *args):
    attachObj = self.scroll if self.isScroll() else self.debugLabel
    if attachObj in self.children:
      self.remove_widget(attachObj)
      self.remove_widget(self.repl)
      self.remove_widget(self.btn_clear)
      self.remove_widget(self.btn_scroll)
      self.remove_widget(self.btn_update)
    else:
      self.add_widget(attachObj)
      self.add_widget(self.repl)
      self.add_widget(self.btn_clear)
      self.add_widget(self.btn_scroll)
      self.add_widget(self.btn_update)

  def showFrame(self, bShow):
    self.bShowFrame = bShow

  def saveLogFile(self):
    if self.bSaveLog:
      logFile = open('log.txt', 'w')
      szString = "\n".join(self.logBuffer)
      logFile.write(szString)
      logFile.close()
  
  def clearPrint(self, inst):
    self.szString = ""
    self.szStatic = ""
    self.bUpdate = True 
     
  def Print(self, szString):
    if type(szString) is not str:
      szString = str(szString)
    if self.bSaveLog:
      self.logBuffer.append(szString)
    if self.szString == "":
      self.szString = szString
    else:
      self.szString = "\n".join([self.szString, szString])

  def log(self, szString, insertPos = -1):
    if type(szString) is not str:
      szString = str(szString)
    if self.bSaveLog:
      self.logBuffer.append(szString)
    self.bUpdate = True
    if self.szStatic == "":
      self.szStatic = szString
    else:
      if insertPos <= 0:
        self.szStatic = "\n".join([szString, self.szStatic])
      else:
        # insert mode
        szTemp = self.szStatic.split("\n")
        szTemp.insert(insertPos, szString)
        self.szStatic = "\n".join(szTemp)
    # write to logger
    Logger.info(szString)
      
  def showProp(self, obj, start = 0):
    for x,i in enumerate(dir(obj)[start:-1]):
      if self.Print(str(x+start)+'.'+i) == False:
        return
  
  def update(self):
    if self.bShowFrame:
      self.checkFrameTime += fFrameTime
      self.frameCount += 1.0
      if self.checkFrameTime > 1.0:
        self.checkFrameTime /= self.frameCount
        self.lastFrameTime = "%.2f" % (1.0/self.checkFrameTime)
        self.checkFrameTime = 0.0
        self.frameCount = 0.0
        self.fps.text = str(self.lastFrameTime)

    if self.szOldString != self.szString:
      self.szOldString = self.szString
      self.bUpdate = True
      
    if self.bUpdate:
      szString = ""
      if self.szStatic == "":
        szString = self.szString
      elif self.szString == "":
        szString = self.szStatic
      else:
        szString = "\n".join([self.szStatic, self.szString])
      self.debugLabel.text = szString
    self.bUpdate = False
    self.szString = ""

#---------------------#
# CLASS : MyScreen
#---------------------#
class MyScreen(ScreenManager, Singleton):
  def __init__(self):
    super(MyScreen, self).__init__(size=WH)
    self.name = "Root Screen"
    self.transition = WipeTransition()
    #SlideTransition(direction="down")

#---------------------#
# CLASS : MyWidget
#---------------------#
class MyWidget(Widget, Singleton):
  def __init__(self):
    super(MyWidget, self).__init__(size=WH)
    self.name = "Root Widget"
   
#---------------------#
# CLASS : MyRoot
#---------------------#
class MyRoot(App, Singleton):
  bPopup = False
  bProgress = False
  progressPopup = None
  progress = None
  appList = []
  jobGroup = []
  myWidget = MyWidget.instance()
  myScreen = MyScreen.instance()
  
  def __init__(self):
    super(MyRoot, self).__init__()
    self.onTouchPrev = self.popup_exit
    Clock.schedule_interval(self.update, fUpdateTime)
    
  def regist(self, app):
    if app in self.appList:
      return
    if not hasattr(app, "update"):
      raise AttributeError("need update function..")
    self.appList.append(app)
    Clock.schedule_interval(app.update, 0)
    
    if hasattr(app, "updateState"):
      Clock.schedule_interval(app.updateState, 0)
  
  def remove(self, app):
    if app in self.appList:
      self.appList.remove(app)
      Clock.unschedule(app.update)
    
  def update(self, frameTime):
    global fFrameTime, fAccTime
    fFrameTime = frameTime
    fAccTime += frameTime
    
    # doing job... it's just for show progress popup.
    while self.jobGroup:
      self.jobGroup[0].update()
      if self.jobGroup[0].isComplete():
        self.jobGroup.pop(0)
      else:
        break
    
    debugPrint = DebugPrint.instance()
    debugPrint.update()
    
    if debugPrint.bShowUpdate:
      self.show_widgets(self.root)      
      for app in self.appList:
        debugPrint.Print("Update : " + app.__class__.__name__)
        
  def show_widgets(self, parent, level=0):
    for child in parent.children:
      name = child.__class__.__name__
      if hasattr(child, "name"):
        name += " - " + child.name
      elif hasattr(child, "text"):
        n = child.text.find("\n")
        szString = child.text[:n] if n > 0 else child.text
        if len(szString) > 20:
          szString = szString[:20] + "..."
        name += " - " + szString
      DebugPrint.instance().Print("    " * level + name)
      self.show_widgets(child, level+1)

  def run(self, startPoint):
    self.regist(startPoint)
    App.run(self)
  
  def exit(self, instance=None):
    DebugPrint.instance().saveLogFile()
    self.stop()
  
  def on_pause(self):
    return True
  
  def add_widget(self, widget):
    self.myWidget.add_widget(widget)
  
  def remove_widget(self, widget):
    self.myWidget.remove_widget(widget)
  
  def add_screen(self, screen):
    self.myScreen.add_widget(screen)
    
  def current_screen(self, screen):
    self.myScreen.current = screen.name
  
  def remove_screen(self, screen):
    self.myScreen.remove_widget(screen)
    
  def build(self):
    self.root = Widget()
    
    global bButtonLock
    bButtonLock = False
    self.bPopup = False
    
    self.root.add_widget(self.myScreen)
    self.root.add_widget(self.myWidget)
    
    debugPrint = DebugPrint.instance()
    debugPrint.init()
    self.root.add_widget(debugPrint)
    
    self.bind(on_start = self.post_build_init)
    return self.root
    
  def setTouchPrev(self, func):
    self.onTouchPrev = func if func else self.popup_exit
  
  def popup_exit(self):
    self.popup("Exit?", self.exit, None)
    
  def popup(self, title, lambdaYes, lambdaNo):
    if self.bPopup:
      return
    self.bPopup = True
    content = Widget()
    sizehintW = 0.9
    sizehintH = 0.3
    btnSizeW = W * sizehintW * 0.5
    btnSizeH = H * sizehintH * 0.5
    popup = Popup(title = title, content=content, auto_dismiss=False, size_hint = (sizehintW, sizehintH))
    popup.a = 0.0
    content.pos = popup.pos
    btn_Yes = Button(text='Yes', pos = (cX-btnSizeW*0.1- btnSizeW*0.75, cY - btnSizeH * 0.75), size=(btnSizeW*0.75, btnSizeH*0.75))
    btn_No = Button(text='No', pos = (cX+btnSizeW*0.1, cY - btnSizeH*0.75), size=(btnSizeW*0.75, btnSizeH*0.75))
    content.add_widget(btn_Yes)
    content.add_widget(btn_No)
    bResult = True
    def closePopup(instance, bYes):
      if bYes and lambdaYes:
        lambdaYes()
      elif lambdaNo:
        lambdaNo()  
      popup.dismiss()
      self.bPopup=False
    btn_Yes.bind(on_press=lambda inst:closePopup(inst, True))
    btn_No.bind(on_press=lambda inst:closePopup(inst, False))
    popup.open()
    return
  
  # create Job insrance
  def newJob(self, title = "Progress.."):
    job = Job(title)
    self.jobGroup.append(job)
    return job
  
  def isProgress(self):
    return self.bProgress
    
  def createProgressPopup(self, title, itemCount):
    self.destroyProgressPopup()
    # loading flag
    self.bProgress = True
    content = Widget()
    sizehintW = 0.3
    sizehintH = 0.25
    self.progressPopup = Popup(title = title, content=content, auto_dismiss=False, size_hint = (sizehintW, sizehintH))
    content.pos = self.progressPopup.pos
    pbSize = mul(WH, (sizehintW * 0.9, sizehintH * 0.9))
    self.progress = ProgressBar(value=0, max=itemCount, pos=sub(cXY, (pbSize[0] * 0.5, sizehintH * H * 0.75)), size=pbSize)
    content.add_widget(self.progress)
    self.progressPopup.open()
    
  def increaseProgress(self):
    if self.progress:
      self.progress.value += 1
    
  def destroyProgressPopup(self):
    if self.progressPopup:
      self.progressPopup.dismiss()
      self.progressPopup = None
    # loading flag
    self.bProgress = False
    
  def _key_handler(self, a,b,c,d,e):
    if b == 1001:
      self.onTouchPrev()
          
  def post_build_init(self,ev):
    global isAndroid
    if isAndroid:
      android.map_key(android.KEYCODE_MENU, 1000) 
      android.map_key(android.KEYCODE_BACK, 1001) 
      android.map_key(android.KEYCODE_HOME, 1002) 
      android.map_key(android.KEYCODE_SEARCH, 1003) 

    win = self._app_window 
    win.bind(on_keyboard=self._key_handler)

#---------------------#
# CLASS : StateItem
#---------------------#
class StateItem():  
  stateMgr = None
  
  def onEnter(self):
    pass
    
  def onUpdate(self):
    pass
    
  def onExit(self):
    pass
  
  def setState(self, state):
    if self.stateMgr:
      self.stateMgr.setState(state)
  
#---------------------#
# CLASS : StateMachine
#---------------------#
class StateMachine(object):
  stateCount = 0
  stateList = {}
  curState = None
  oldState = None
  
  def __init__(self):
    object.__init__(self)
    self.stateCount = 0
    self.stateList = {}
    self.curState = None
    self.oldState = None
    
  def addState(self, stateItem):
    self.stateList[stateItem] = stateItem()
    self.stateCount = len(self.stateList)
    stateItem.stateMgr = self
  
  def getCount(self):
    return self.stateCount
    
  def isState(self, index):
    return index == self.curState
    
  def getState(self):
    return self.curState

  def getStateItem(self):
    if self.curState:
      return self.stateList[self.curState]

  def setState(self, index, reset=False):
    if index:
      if index != self.curState:
        self.oldState = self.curState
        self.curState = index
        if self.oldState:
          self.stateList[self.oldState].onExit()
        self.stateList[index].onEnter()
      elif reset:
        self.stateList[index].onEnter()

  def updateState(self, *args):
    if self.curState:
      self.stateList[self.curState].onUpdate()
  
  def update(self, dt):
    '''must override'''
    pass

#---------------------#
# MultiMethod
#---------------------#
registry = {}

class MultiMethod(object):
    def __init__(self, name):
        self.name = name
        self.typemap = {}
    def __call__(self, *args):
        types = tuple(arg.__class__ for arg in args) # a generator expression!
        function = self.typemap.get(types)
        if function is None:
            raise TypeError("no match")
        return function(*args)
    def register(self, types, function):
        if types in self.typemap:
            raise TypeError("duplicate registration")
        self.typemap[types] = function

def multimethod(*types):
    def register(function):
        name = function.__name__
        mm = registry.get(name)
        if mm is None:
            mm = registry[name] = MultiMethod(name)
        mm.register(types, function)
        return mm
    return register
    
overload = multimethod

@overload()  
def getX():
  return cX
  
@overload(int)  
def getX(a):
  return cX*a

@overload(int, int)
def getX(a,b):
  return cX*b
  
#---------------------#
# set global instance
#---------------------#
setGlobalInstance()