from copy import copy
from xml.etree.ElementTree import Element, dump, parse, SubElement, ElementTree

import Utility as Util
from Utility import *

from ObjectBase import Gate

#---------------------#
# Global Instance
#---------------------#
def setGlobalInstance(WorldEdit):
  global gWorldEdit
  gWorldEdit = WorldEdit.instance()
  
#---------------------#
# class : Bridge
#---------------------#
class Bridge(Singleton, Widget):
  bridgeMap = {}
  gateMap = {}
  def __init__(self):
    Widget.__init__(self, size=WH)
    self.bridgeMap = {} # ex)bridgeMap[id1] = {id2:[gate1ID, gate2ID], ...}
    self.gateMap = {} # ex)gateMap[gate1id] = gate2id
    
  def load(self, parentTree):
    if parentTree != None:
      xml_tree = parentTree.find( self.__class__.__name__)
      if xml_tree != None:
        _from = xml_tree.findall("from")
        for obj1 in _from:
          # loading progress
          gMyRoot.increaseLoading()
          id1 = int(obj1.get("id"))
          _toList = eval(obj1.get("to"))
          self.bridgeMap[id1] = _toList
          # generate gateMap
          for id2 in _toList:
            gate1ID, gate2ID = _toList[id2]
            self.gateMap[gate1ID] = gate2ID
            
          
  def save(self, parentTree, counter):
    className = self.__class__.__name__
    xml_data = SubElement(parentTree, className)
    counter.value += len(self.bridgeMap)
    for id1 in self.bridgeMap:
      link = SubElement(xml_data, "from")
      link.set("id", str(id1))
      link.set("to", str(self.bridgeMap[id1]))
  
  def remove(self):
    # clear
    self.canvas.clear()
    for child in self.canvas.children:
      self.canvas.remove(child)
    
    self.bridgeMap = {}   
    # detach self
    if self.parent:
      self.parent.remove_widget(self)
      
  def draw(self):
    gWorldEdit.gameScreen.add_to_bg(self)
  
  def drawBridge(self):
    self.canvas.clear()
    for child in self.canvas.children:
      self.canvas.remove(child)
    children = copy(gWorldEdit.getCurrentLevel().get_childObj())
    childrenID = [child.getID() for child in children]
    while childrenID:
      id1 = childrenID.pop()
      if id1 in self.bridgeMap:
        for id2 in self.bridgeMap[id1]:
          if id2 in childrenID:
            obj1 = gWorldEdit.getObj(id1)
            obj2 = gWorldEdit.getObj(id2)
            if obj1 and obj2:
              # draw bridge
              with self.canvas:
                Color(1,1,1,0.5)
                Line(points = obj1.center + obj2.center, width = 10)
              # recalc gate pos
              if id1 in self.bridgeMap and id2 in self.bridgeMap[id1]:
                gate1 = gWorldEdit.getObj(self.bridgeMap[id1][id2][0])
                self.calcGatePos(gate1, obj1, obj2)
              if id2 in self.bridgeMap and id1 in self.bridgeMap[id2]:
                gate2 = gWorldEdit.getObj(self.bridgeMap[id2][id1][0])
                self.calcGatePos(gate2, obj2, obj1)
  
  def getLinkedGate(self, gate):
    if gate.getID() in self.gateMap:
      otherGateID = self.gateMap[gate.getID()]
      return gWorldEdit.getObj(otherGateID)
    return None
  
  def getLinkedObjWithGate(self, gateObj):
    gateID = gateObj.getID()
    if gateObj.parentObj != None and gateObj.parentObj.getID() in self.bridgeMap:
      obj2Maps = self.bridgeMap[gateObj.parentObj.getID()]
      for id2 in obj2Maps.keys():
        if gateID == obj2Maps[id2][0]:
          return gWorldEdit.getObj(id2)
    return None
    
  def hasBridge(self, obj):
    return obj and (obj.getID() in self.bridgeMap)
                      
  def isLinked(self, obj1, obj2):
    if obj1 and obj2 and obj1 is not obj2:
      id1 = obj1.getID()
      id2 = obj2.getID()
      if id1 in self.bridgeMap and id2 in self.bridgeMap and \
        id1 in self.bridgeMap[id2] and id2 in self.bridgeMap[id1]:
        return True
    return False
    
  def breakLink(self, obj1):
    if obj1:
      id1 = obj1.getID()
      if id1 in self.bridgeMap:
        linkedIDList = copy(self.bridgeMap[id1])
        for id2 in linkedIDList:
          self.removeBridge(obj1, gWorldEdit.getObj(id2))
  
  def calcGatePos(self, gate, obj1, obj2):
    if gate and obj1 and obj2:
      vDir = normalize(sub(obj2.center, obj1.center))
      if vDir[1] == 0.0 or abs(vDir[0]/vDir[1]) > W/H:
        # left or right direction
        vDir = mul(vDir, abs(W * 0.4 / vDir[0]))
      else:
        # top or bottom.direction
        vDir = mul(vDir, abs(H * 0.3 / vDir[1]))
      gate.center = add(mul(cXY, (1.0, 0.95)), vDir)
     
  def addBridge(self, obj1, obj2):
    if obj1 and obj2 and obj1 is not obj2:
      def addGate(obj1, obj2):
        id1 = obj1.getID()
        id2 = obj2.getID()
        # add new gate
        gate = obj1.add_childObj("Gate")
        gateID = -1
          
        if gate:
          gateID = gate.getID()
          gateName = obj2.getName() + " " + obj2.getType()
          gate.setName(gateName)
          self.calcGatePos(gate, obj1, obj2)
        return gateID
        
      # create gates
      gate1ID = addGate(obj1, obj2)
      gate2ID = addGate(obj2, obj1)
      
      # add new bridge item - { id2:[gate1id, gate2id],... }
      id1 = obj1.getID()
      id2 = obj2.getID()
      
      # bridgeMap
      if id1 in self.bridgeMap:
        self.bridgeMap[id1][id2] = [gate1ID, gate2ID]
      else:
        self.bridgeMap[id1] = { id2:[gate1ID, gate2ID] }
        
      if id2 in self.bridgeMap:
        self.bridgeMap[id2][id1] = [gate2ID, gate1ID]
      else:
        self.bridgeMap[id2] = { id1:[gate2ID, gate1ID] }
        
      # gateMap
      self.gateMap[gate1ID] = gate2ID #if not isinstance(obj2, Gate) else obj2.getID()
      self.gateMap[gate2ID] = gate1ID #if not isinstance(obj1, Gate) else obj1.getID()
         
      # add line
      if gWorldEdit.getCurrentLevel() == obj1.parentObj:
        with self.canvas:
          Color(1,1,1,0.5)
          Line(points = obj1.center + obj2.center, width = 10)   
        
  def removeBridge(self, obj1, obj2):
    if obj1 and obj2 and obj1 is not obj2:
      if self.isLinked(obj1, obj2):
        id1 = obj1.getID()
        id2 = obj2.getID()
        # remove gate and pop bridge
        def removeGate_popBridge(id1, id2):
          # remove gate
          if id1 in self.bridgeMap and id2 in self.bridgeMap[id1]:
            gate1 = gWorldEdit.getObj(self.bridgeMap[id1].pop(id2)[0])
            if gate1:
              gate1ID = gate1.getID()
              if gate1ID in self.gateMap:
                self.gateMap.pop(gate1ID)
              gate1 and gate1.remove()
          # pop empty map item
          if id1 in self.bridgeMap and not self.bridgeMap[id1]:
            self.bridgeMap.pop(id1)
        # do it...
        removeGate_popBridge(id1, id2)
        removeGate_popBridge(id2, id1)
      self.drawBridge()
  
  # Bridge method
  def checkBridge(self, obj1, obj2):
    if obj1 and obj2 and obj1 is not obj2 and obj1.bEnableBridge and obj2.bEnableBridge:
      if self.isLinked(obj1, obj2):
        self.removeBridge(obj1, obj2)
      else:
        self.addBridge(obj1, obj2)