import Utility as Util
from Utility import *
from Character import *
from ResourceMgr import gResMgr

from xml.etree.ElementTree import Element, dump, parse, SubElement, ElementTree

icon_size = WRect(0.1)

#---------------------#
# Global Instance
#---------------------#
def setGlobalInstance():
  global gWorld
  gWorld = World.instance()

#---------------------#
# class : WorldBase
#---------------------#
class BaseObject(Scatter):
  namelistFile = ""
  namelist = None
  name = "No name"
  
  def __init__(self, parentObj, xml_data = None):
    Scatter.__init__(self, size=icon_size)
    self.parentObj = parentObj
    self.pos = cXY
    self.do_translation = True
    self.do_rotation = True
    self.do_scale = True
    with self.canvas:
      self.boxColor = Color(0.7,0.7,1.0,0.0)
      Rectangle(size=self.size)
      Color(1,1,1)
      Rectangle(texture=gResMgr.getTex("star"), size=self.size)
    self.label = Label(text=self.name, center=mul(self.size, (0.5, 1.0)))
    self.label.pos[1] += self.label.size[1]
    self.add_widget(self.label)
    self.villages = {}
    
    self.bind(on_touch_down = self.touch_down,
      on_touch_move = self.touch_move,
      on_touch_up = self.touch_up)
    
    # set name
    if xml_data == None:
      self.setNewName(self)
    else:
      self.load(xml_data)
      
  def load(self, xml_data):
    self.setName(xml_data.get("name"))
    self.pos = eval(xml_data.get("pos"))
    
  def save(self, parentTree):
    obj = SubElement(parentTree, self.__class__.__name__)
    obj.text = self.name
    obj.set("name", self.name)
    obj.set("pos", str(self.pos))
    obj.tail = "\n"
    
  @classmethod
  def loadNamelist(cls):
    if cls.namelistFile == "":
      raise "You must set namelistFile.. ex)city_names.txt"
    f = open(os.path.join("data", cls.namelistFile),"r")
    cls.namelist = map(lambda x:x.strip(), list(f))
    f.close()    
  
  @classmethod
  def setNewName(cls, obj):
    if cls.namelist and len(cls.namelist) > 0:
      name = random.choice(cls.namelist).strip()
      cls.namelist.remove(name)
      obj.setName(name)
  
  @classmethod
  def checkName(cls, obj):
    '''if is there name then remove..'''
    if obj.name in cls.namelist:
      cls.namelist.remove(obj.name)
      
  def setName(self, name):
    self.name = name
    self.label.text = name
    self.checkName(self)
    
  def getName(self):
    return self.name
    
  def remove(self, *args):
    raise "must implement remove"
  
  def touch_down(self, inst, touch):  
    if self.collide_point(*touch.pos):
      #self.do_translation = gWorld.isEditMode
      touch.grab(self)
      self.boxColor.a = 0.3
      Clock.schedule_once(self.remove, 1.0)
      gWorld.selectObj(self)
      # double tap
      if touch.is_double_tap:
        self.remove()
  
  def touch_move(self, inst, touch):
    if self == touch.grab_current:
      Clock.unschedule(self.remove)
    
  def touch_up(self, inst, touch):
    if self == touch.grab_current:
      touch.ungrab(self)
      self.boxColor.a = 0.0
      Clock.unschedule(self.remove)

#---------------------#
# class : World
#---------------------#    
class World(Singleton):
  city = {}
  gameScreen = None
  selectedObj = None
  isEditMode = False
  widgets = Widget()
  widgets.name = "WorldEditUI"
  inited = False
  
  def build_ui(self):
    if not self.inited:
      self.inited = True
      btn_size = (300, 100)
      btn_pos = sub(WH, btn_size)
      self.btn_edit = Button(text="Edit Mode", pos=btn_pos, size=btn_size)
      self.btn_edit.bind(on_release = lambda inst:self.setEditMode(inst, self.isEditMode))
      btn_pos[1] -= btn_size[1]
      
      def add_button(text, onRelease):
        btn = Button(text=text, pos=btn_pos, size=btn_size)
        btn.bind(on_release = onRelease)
        self.widgets.add_widget(btn)
        btn_pos[1] -= btn_size[1]
      add_button("add city", self.add_city)
      add_button("add village", self.add_village)
      add_button("add building", self.add_building)
      add_button("add npc", self.add_npc)
      add_button("remove", lambda x:self.remove_city(self.getSelected()))
      
      self.selectObjName = TextInput(text = "", multiline=False, size=btn_size, pos=btn_pos,
        background_color=(1,1,1,0.1), foreground_color=(1,1,1,1))
      self.selectObjName.bind(on_text_validate = self.setSelectedObjName)
      self.widgets.add_widget(self.selectObjName)
      
      self.parentName = Label(text="World", font_size="30dp", pos=(0,H-100), size=(W,100))

    self.gameScreen.add_to_ui(self.btn_edit)
    self.gameScreen.add_to_ui(self.parentName)
    self.setEditMode(None, True)
    
  def setEditMode(self, inst, bEdit):
    self.isEditMode = bEdit
    if self.isEditMode and not self.widgets.parent:
      self.gameScreen.add_to_ui(self.widgets)
    elif self.widgets.parent:
      self.widgets.parent.remove_widget(self.widgets)
      
  def setSelectedObjName(self, inst):
    if self.selectedObj:
      self.selectedObj.setName(inst.text)
      
  def selectObj(self, obj):
    self.selectedObj = obj
    self.selectObjName.text = obj.getName() if obj else ""
  
  def getSelected(self):
    return self.selectedObj
    
  def isSelected(self, obj):
    return self.selectedObj is obj
  
  def add_city(self, inst, xml_data = None):
    city = City(self, xml_data)
    self.city.append(city)
    self.gameScreen.add_to_bg(city)
  
  def add_village(self, *args):
    pass
    
  def add_building(self, *args):
    pass
    
  def add_npc(self, *args):
    pass
    
  def clear(self):
    self.selectObj(None)
    self.city=[]
    
  def remove_city(self, city):
    if city:
      self.city.remove(city)
      city.parent.remove_widget(city)
      if self.isSelected(city):
        self.selectObj(None)

  def load(self, filename, screen):
    self.gameScreen = screen
    self.build_ui()
    self.clear()
    self.filename = filename
    if os.path.isfile(filename):
      tree = parse(filename)
      root = tree.getroot()
      xml_cities = root.findall("City")
      City.loadNamelist()
      for xml_data in xml_cities:
        self.add_city(None, xml_data)
    
  def save(self, filename):
    root = Element("World")
    for city in self.city:
      city.save(root)
    ElementTree(root).write(filename)
  
class City(BaseObject):
  namelistFile = "city_names.txt"
  
  def remove(self, *args):
    self.parentObj.remove_city(self)

class Village:
  def __init__(self):
    self.buildings = {}

class Building:
  def __init__(self):
    self.characters = {}
    
#---------------------#
# set global instance
#---------------------#
setGlobalInstance()