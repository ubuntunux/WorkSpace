import Utility as Util
from Utility import *

from Globals import *
from Particle import *
from ResourceMgr import *
from Character import *
from World import *

#---------------------#
# Global Instance
#---------------------#
def setGlobalInstance():
  global gMyGame, gGameScreen
  gGameScreen = MyGame_Screen.instance()
  gMyGame = MyGame_Mgr.instance()

#---------------------#
# Class
#---------------------#
# MYGAME_SCREEN
class MyGame_Screen(Screen, Singleton):      
  def __init__(self):
    Screen.__init__(self, name="MyGame")
  
  def build_ui(self):
    # add bg
    self.layer_bg = Widget()
    self.layer_bg.name="layer_bg"
    self.add_widget(self.layer_bg)

    # add fx layer
    self.layer_fx = Widget()
    self.layer_fx.name = "layer_fx"
    self.add_widget(self.layer_fx)
    
    # add ui layer
    self.layer_ui = Widget()
    self.layer_ui.name = "layer_ui"
    self.add_widget(self.layer_ui)

  def create_screen(self):
    self.build_ui()
    gMyRoot.add_screen(self)
    gMyRoot.current_screen(self)
    
  def remove_screen(self):
    gMyRoot.remove_screen(self)
    self.clear_widgets()
    self.layer_bg.clear_widgets()
    self.layer_fx.clear_widgets()
    self.layer_ui.clear_widgets()  
    
  def add_to_ui(self, widget):
    self.layer_ui.add_widget(widget)
    
  def add_to_bg(self, widget):
    self.layer_bg.add_widget(widget)

#---------------------#
# CLASS : MyGameStateMgr
#---------------------#
class MyGame_Mgr(Singleton): 
  def __init__(self):
    self.running = False
    self.onExitFunc = None
    self.filename = ""
   
  def bind_OnExit(self, func):
    self.onExitFunc = func

  def onTouchPrev(self, *args):
    self.running = False
    self.save()
    gWorld.clear()
    gFxMgr.setActive(False)
    gFxMgr.remove_emitters()
    gGameScreen.remove_screen()
    gMyRoot.remove(self)
    if self.onExitFunc:
      self.onExitFunc()
    gMyRoot.setTouchPrev(None)
    
  def update(self, dt):
    pass
    
  def load(self, filename):
    if self.running:
      return
    self.running = True
    self.filename = filename
    gMyRoot.regist(self)
    gMyRoot.setTouchPrev(self.onTouchPrev)
    gGameScreen.create_screen()
    gWorld.load(self.filename, gGameScreen)
    
  def save(self, *args):
    if self.filename:
      if not os.path.isdir(gSaveDir):
        os.mkdir(gSaveDir)
      gWorld.save(self.filename)
   
#---------------------#
# set global instance
#---------------------#
setGlobalInstance()