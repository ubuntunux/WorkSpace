from copy import copy
from xml.etree.ElementTree import Element, dump, parse, SubElement, ElementTree

import Utility as Util
from Utility import *
from kivy.animation import Animation
from ResourceMgr import gResMgr

from Globals import *

#---------------------#
# Global Variable
#---------------------#
icon_size = WRect(0.1)

#---------------------#
# Global Instance
#---------------------#
def setGlobalInstance(WorldEdit, Bridge):
  global gWorldEdit
  global gBridge
  global gPlayer
  gWorldEdit = WorldEdit.instance()
  gBridge = Bridge.instance()
  gPlayer = Player.instance()
  
#---------------------#
# class : ObjectBase
#---------------------#
class BaseObject(Scatter, StateMachine):
  ID = -1
  xml_data = None
  namelistFile = ""
  namelist = []
  name = "No name"
  icon = ""
  body = None
  label = None
  bUniqueName = True
  bDrawTypeName = True
  parentObj = None
  childTypes = []
  childObj = []
  
  bHasDoor = False
  bFreeMoveType = False
  bEnterPoint = False # one of entry point on player enter the level
  
  # editmode properties
  bTouched = False
  bCreatable = True
  bMovable = True
  bDeletable = True
  bEnableBridge = False
  bRedrawBridge = False
  bDrawAlways = False
  pDrawOnObj = None

  # transform method
  curPos = None # real position, pos is relative position
  bJump = False
  fJump = False
  bMove = False
  vStartPos = None
  vTargetPos = None
  pTargetObj = None
  pStartFromObj = None
  nStartFromObjID = -1
  pCurArriveObj = None
  nCurArriveObjID = -1
  vMoveDir = None
  fMoveTime = 0.0
  fMoveTimeAcc = 0.0
  fFloorPos = 0.0
    
  def __init__(self):
    # class method - load name library
    self.loadNamelist()
    
    # state machine init
    StateMachine.__init__(self)

    # init scatter
    Scatter.__init__(self, size=icon_size)
    self.setPos(cXY)
    self.do_translation = self.bMovable
    self.do_rotation = False
    self.do_scale = False
    self.auto_bring_to_front = False
    
    # set box region
    self.body = Scatter(size=self.size, pos=(0,0))
    self.body.do_translation = False
    self.body.do_rotation = False
    self.body.do_scale = False
    self.body.auto_bring_to_front = False
    with self.body.canvas:
      self.boxColor = Color(0.7,0.7,1.0,0.0)
      Rectangle(size=self.size)
      self.objColor = Color(1,1,1)
      self.box = Rectangle(size=self.size)
    self.add_widget(self.body)
    
    # attach name label
    self.label = Label(text=self.name, center=mul(self.size, (0.5, 1.0)))
    self.label.pos[1] += self.label.size[1] * 0.15
    self.add_widget(self.label)
    
    # bind func
    self.bind(on_touch_down = self.touch_down,
      on_touch_move = self.touch_move,
      on_touch_up = self.touch_up)
      
  def setPos(self, pos):
    self.pos = copy(pos)
    self.curPos = copy(pos)
    
  def getPos(self): return self.pos
  def getOffsetPos(self): return sub(self.pos, (0.0, self.size[1]*0.25))
  def getCurPos(self): return self.curPos
  def getCurOffsetPos(self): return sub(self.curPos, (0.0, self.size[1]*0.25))
  def setMovable(self, bMovable):
   self.bMovable = bMovable
   self.do_translation = bMovable
  def isMove(self): return self.bMove
  def isJump(self): return self.bJump
  
  def getType(self):
    return self.__class__.__name__
 
  # reset data  
  def reset(self, parentObj, xml_data):
    if self == parentObj:
      return
    #init data
    self.xml_data = xml_data
    self.parentObj = parentObj
    self.childObj = []
    self.bTouched = False
    self.bRedrawBridge = False
    self.bMove = False
    self.bJump = False
    self.fJump = 0.0
    self.vStartPos = [0,0]
    self.vTargetPos = [0,0]
    self.pTargetObj = None
    self.pStartFromObj = None
    self.nStartFromObjID = -1
    self.pCurArriveObj = None
    self.nCurArriveObjID = -1
    self.pDrawOnObj = None
    self.vMoveDir = [0,0]
    self.fMoveTime = 0.0
    self.fMoveTimeAcc = 0.0
    
    # set icon
    if self.icon:
      self.box.texture = gResMgr.getTex(self.icon)
        
    # create new data
    if xml_data == None:
      self.setNewName(self)
      self.setID(-1)
      self.setPos(cXY)
      # add door
      if self.bHasDoor:
        door = self.add_childObj("Door")
        door.center = mul(WH, (0.5, 0.15))
        door.setPos(door.pos)
    # adjust loading data
    else:
      self.setID(int(xml_data.get("id")))
      self.setName(xml_data.get("name"))
      # adjust screen ratio
      self.setPos(mul(eval(xml_data.get("pos")), (gWorldEdit.widthRatio, gWorldEdit.heightRatio)))
      self.setRotation(eval(xml_data.get("rotation")))
      
    # set floor pos
    self.fFloorPos = self.getCurPos()[1]
    # add to worldedit
    if self.bDrawAlways:
      gWorldEdit.addDrawAlwaysObj(self)
    # regist object
    gWorldEdit.registObjID(self)
  
  def remove(self):
    if not self.bDeletable and gWorldEdit.getCurrentLevel() == self.parentObj:
      return False
    # deleted log
    #log(" ".join(["Removed", self.getType(), ":", self.getTitle()]))
      
    # recursive
    childObj = copy(self.childObj)
    for child in childObj:
      child.remove()
    
    # movement stop 
    self.stop()
    
    # break link
    if isinstance(self, Gate) and isinstance(self.parentObj, Road):
      gBridge.breakLink(gBridge.getParentOfGate(self))
    else:
      # maybe.. I have gate. cause try to break link
      gBridge.breakLink(self)
    
    # pop my widget from parent 
    if self.parent:
      self.parent.remove_widget(self)
      
    # pop self from parent
    if self.parentObj:
      self.parentObj.pop_childObj(self)  
    self.parentObj = None
    
    # unregist
    gWorldEdit.unregistObjID(self)
    return True
    
  @classmethod
  def loadNamelist(cls):
    if cls.namelistFile and not cls.namelist:
      filepath = os.path.join("data", cls.namelistFile)
      if os.path.isfile(filepath):
        f = open(filepath, "r")
        cls.namelist = map(lambda x:x.strip(), list(f))
        f.close()    
  
  @classmethod
  def setNewName(cls, obj):
    if cls.namelist and len(cls.namelist) > 0:
      name = random.choice(cls.namelist).strip()
      obj.setName(name)
    else:
      # set default name
      obj.setName(cls.name)
  
  @classmethod
  def checkName(cls, objName):
    '''if is there name then remove..'''
    if cls.bUniqueName and objName in cls.namelist:
      cls.namelist.remove(objName)
      
  def setName(self, name):
    self.name = name
    self.label.text = self.getTitle()
    self.checkName(self.name)
    
  def getName(self):
    return self.name
  
  def getNameWithID(self):
    return self.name + "[" + str(self.ID) + "]"
  
  def getTitle(self):
    if self.bDrawTypeName:
      return self.name + " " + self.__class__.__name__
    else:
      return self.name
  
  def getID(self):
    return self.ID 
    
  def setID(self, ID):
    self.ID = ID
    
  # Display ID 
  def showID(self, bShow):
    # toggle id label
    if bShow:
      self.label.text = "ID : " + str(self.ID) + "\n" + self.getTitle()
    else:
      self.label.text = self.getTitle()
      
  def draw(self):
    # check, is valid object?
    if self.getID() == -1:
      return
    # pop.from.old.parent
    if self.parent != None:
      self.parent.remove_widget(self)
    # calc pos
    self.pDrawOnObj = None
    if self.bDrawAlways:
      # draw to current position
      if self.parentObj == gWorldEdit.getCurrentLevel():
        self.pos = copy(self.curPos)
      # draw to parent position
      elif self.parentObj != None:
        prevParentObj = self.parentObj
        parentObj = self.parentObj.parentObj
        while parentObj:
          if gWorldEdit.getCurrentLevel() == parentObj:
            self.pos = prevParentObj.getCurOffsetPos()
            self.pDrawOnObj = prevParentObj
            break
          prevParentObj = parentObj
          parentObj = parentObj.parentObj
        else:
          # currentLevel not matched parent level, cause do not draw.
          return
    # add to parent
    gWorldEdit.gameScreen.add_to_bg(self)
    # show id
    self.showID(gWorldEdit.isEditMode)
    
  def load(self, parentTree):
    xml_data = parentTree.find(self.__class__.__name__)\
      if parentTree != None else None
    # loading progress
    gMyRoot.increaseLoading()
    self.reset(None, xml_data)
    self.load_child(xml_data)
      
  def load_child(self, currentTree):
    # load child data
    if currentTree != None:   
      # loading progress
      gMyRoot.increaseLoading()
      for childType in self.childTypes:
        xml_tree = currentTree.findall(childType)
        if xml_tree != None:
          for xml_data in xml_tree:
            child = self.add_childObj(childType, xml_data)
            child.load_child(xml_data)
  
  def postLoadProcess(self):
    # clear xml data
    self.xml_data = None
  
  def save(self, parentTree, counter):
    counter.value += 1
    className = self.__class__.__name__
    if parentTree == None:
      xml_data = Element(className)
    else:
      xml_data = SubElement(parentTree, className)
    xml_data.set("id", str(self.getID()))
    xml_data.set("name", self.name)
    xml_data.set("pos", str(self.getCurPos()))
    xml_data.set("rotation", str(self.getRotation()))
    if self.pCurArriveObj:
      xml_data.set("arriveObjID", str(self.pCurArriveObj.getID()))
    if self.pStartFromObj:
      xml_data.set("startFromObjID", str(self.pStartFromObj.getID()))
      
    for child in self.childObj:
      child.save(xml_data, counter)
    return xml_data
    
  def isTouched(self):
    return self.bTouched
    
  def append_childObj(self, childObj):
    self.childObj.append(childObj)
   
  def add_childObj(self, childType, xml_data = None):
    if childType in self.childTypes:
      childClass = eval(childType)
      child = None
      # check singleton - cannot add, but just only modify
      if hasattr(childClass, "instance"):
        # pop from parent
        child = childClass.instance()
        if child.parentObj:
          child.parentObj.pop_childObj(child)
        
        if child.getID() == -1:
          # when loaded...
          child.reset(self, xml_data)
        else:
          # set new parent
          child.set_parentObj(self)
      else:
        # add new child object or loaded
        child = childClass()
        child.reset(self, xml_data)
      self.append_childObj(child)
      if gWorldEdit.getCurrentLevel() == self:
        child.draw()
      return child
  
  # clear    
  def clear(self):
    childObj = copy(self.childObj)
    for child in childObj:
      child.remove()
  
  # recursive check, is in parent list
  def isInParentList(self, obj):
    parentObj = self.parentObj
    while obj and parentObj:
      if obj == parentObj:
        return True
      parentObj = parentObj.parentObj
    return False
  
  # recursive check, is in child list
  def isInChildList(self, obj):
    for child in self.childObj:
      if child == obj:
        return True
      elif child.isInChildList(obj):
        return True
    return False
      
  def getChildTypes(self):
    return self.childTypes
  
  def get_childObj(self):
    return self.childObj
    
  def pop_childObj(self, obj):
    obj.parentObj = None
    if obj in self.childObj:
      # pop obj from childObj
      self.childObj.remove(obj)
    # pop from parent widget
    if obj.parent:
      obj.parent.remove_widget(obj)
    
  def draw_childObj(self):
    for child in self.childObj:
      child.draw()
  
  def get_parentObj(self):
    return self.parentObj
  
  def set_parentObj(self, parentObj):
    self.parentObj = parentObj
    
  def change_parentObj(self, newParentObj):
    if newParentObj != None and newParentObj != self.parentObj and \
      self.getType() in newParentObj.getChildTypes():
        if self.parentObj:
          self.parentObj.pop_childObj(self)
        self.set_parentObj(newParentObj)
        newParentObj.append_childObj(self)
        # set real position ( curPos )
        self.setPos(self.getPos())
        # draw
        if self.bDrawAlways or gWorldEdit.getCurrentLevel() == newParentObj:
          self.draw()
          
  def findGate(self, vMoveDir):
    #log("find gate")
    vMoveDir = normalize(mul(vMoveDir, (0.8,0.6)))
    #find best gate....
    maxDot = -1.0
    gateObj = None
    for child in self.childObj:
      if child.bEnterPoint:
        vDir = sub(mul(cXY, (1.0, 0.95)), child.center)
        vDir = normalize(vDir)
        curDot = dot(vDir, vMoveDir)
        if curDot > maxDot:
          maxDot = curDot
          gateObj = child
          #log(gateObj.getName() + " " + str(curDot))
    return gateObj
    
  # on enter or exit to other level
  def exitLevel(self, depth = 0):
    if depth == 0:
      for child in self.childObj:
        child.exitLevel(depth+1)
    self.pDrawOnObj = None
  
  def showPopup(self, *args):
    gWorldEdit.popupMenu.showPopup(self)
 
  def touch_down(self, inst, touch):
    self.do_translation = gWorldEdit.isEditMode and self.bMovable
    if self.collide_point(*touch.pos):
      # for select only one object
      if not gWorldEdit.isEditMode:
        dist = getDist(self.center, touch.pos)
        touchObj, touchDist = gWorldEdit.getTouchObj()
        if touchObj != None and touchObj != self:
          if touchDist < dist:
            return
          else:
            touchObj.touch_up(inst, touch, True)
        gWorldEdit.setTouchObj(self, dist)
      
      # set touch
      self.bTouched = True
      # touch flag - check touch something? by gWorldEdit
      touch.bTouched = True
      touch.grab(self)
      
      # set selected color
      self.boxColor.a = 0.3
      
      # set select obj
      gWorldEdit.selectObj(self)
      
      # check edit
      if gWorldEdit.isEditMode:  
        self.bRedrawBridge = False
        # set delete callback
        if self.bDeletable:
          Clock.schedule_once(self.showPopup, 0.3)
        # double tap - enter the level
        if touch.is_double_tap:
          gWorldEdit.setCurrentLevel(self)
      
  def touch_move(self, inst, touch):
    if self == touch.grab_current:
      if gWorldEdit.isEditMode:
        self.bRedrawBridge = True
      Clock.unschedule(self.showPopup)
      
  def touch_up(self, inst, touch, bForce=False):
    if self == touch.grab_current or bForce:
      if gWorldEdit.getTouchObj()[0] == self:
        gWorldEdit.setTouchObj(None, 0.0)
      self.bTouched = False
      touch.ungrab(self)
      self.boxColor.a = 0.0
      Clock.unschedule(self.showPopup)
      # edit mode
      if gWorldEdit.isEditMode:
        # redraw bridge
        if self.bRedrawBridge:
          if gBridge.hasBridge(self):
            # redraw bridge and recalculate gate pos
            gBridge.drawBridge(self.bRedrawBridge)
          self.bRedrawBridge = False
        # set pos
        if self.parentObj == gWorldEdit.getCurrentLevel():
          self.setPos(self.pos)
        
  def checkInRegion(self):
    x, y = self.getPos()
    if x < W * 0.2:
      x = W * 0.2
    elif x + self.size[0] > W * 0.8:
      x = W * 0.8 - self.size[0]
    if y < H * 0.2:
      y = H * 0.2
    elif y + self.size[1] > H * 0.8:
      y = H * 0.8 - self.size[1]
    self.pos = (x,y)
    
  # update
  def update(self, dt):
    if self.bMove or self.bJump:
      self.updateMove(dt)
    
  # move method 
  def updateMove(self, dt):
    pos = self.getPos()
    # move
    if self.bMove:
      pos = add(pos, mul(self.vMoveDir, gWalk * dt))
      self.fMoveTimeAcc += dt
      if self.fMoveTimeAcc >= self.fMoveTime:
        self.bMove = False
        self.fMoveTime = 0.0
        self.fMoveTimeAcc = 0.0
        if self.bJump:
          pos = (self.vTargetPos[0], pos[1])
        else:
          pos = copy(self.vTargetPos)
      ratio = self.fMoveTimeAcc / self.fMoveTime if self.fMoveTime > 0.0 else 1.0
      ratio = min(1.0, max(0.0, ratio))
      self.fFloorPos = self.vStartPos[1] * (1.0-ratio) + self.vTargetPos[1]*ratio
      self.jump()
      
    # jump
    if self.bJump:
      self.fJump -= gGravity * dt
      pos = add(pos, (0.0, self.fJump * dt))
      if self.fJump <= 0.0 and self.getPos()[1] <= self.fFloorPos:
        pos = (pos[0], self.fFloorPos)
        self.bJump = False
        
    # set position
    self.setPos(pos)
    
    # check arrived to the target
    if not self.bMove and not self.bJump:
      self.arrivedAt()
  
  def getRotation(self):
    return self.body.rotation

  def setRotation(self, degree):
    self.body.rotation = degree
      
  def getTargetObj(self):
    return self.pTargetObj
     
  def arrivedAt(self):
    self.stop()
    if self == gPlayer and self.pTargetObj != None:
      # up to level
      if isinstance(self.pTargetObj, Door):
        gWorldEdit.upToTheLevel()
      # move to the parent of linked gate
      elif isinstance(self.pTargetObj, Gate):
        #check linked obj count - if gate has many linked obj, stop for user choose
        # will be return. so you must set arrive obj in below method
        self.move_to_ParentOfLinkedGate(self.pTargetObj)
        return
      # enter the level
      elif self.getType() in self.pTargetObj.getChildTypes():
        # change parent
        self.change_parentObj(self.pTargetObj)
        gWorldEdit.setCurrentLevel(self.pTargetObj)
        self.pTargetObj = self.pTargetObj.findGate(self.vMoveDir)
        if self.pTargetObj:
          self.setPos(self.pTargetObj.getOffsetPos())
    self.pCurArriveObj = self.pTargetObj
    self.pTargetObj = None
    self.pStartFromObj = None
  
  def jump(self, force=gJump):
    if not self.bJump:
      self.bJump = True
      self.fJump = force
      if not self.bMove:
        self.fFloorPos = self.getPos()[1]
  
  def move(self, targetPos, targetObj = None):
    self.pTargetObj = targetObj
    dist = getDist(targetPos, self.pos)
    # check, can move?
    if dist > 0.001:
      self.bMove = True
      self.fMoveTime = dist / gWalk
      self.fMoveTimeAcc = 0.0
      self.pStartFromObj = self.pDrawOnObj or self.pCurArriveObj
      self.vStartPos = copy(self.getPos())
      self.vTargetPos = copy(targetPos)
      self.pCurArriveObj = None
      self.vMoveDir = normalize(sub(targetPos, self.pos))
      # set parent the current level
      self.change_parentObj(gWorldEdit.getCurrentLevel())
    else:
      self.arrivedAt()
     
  def move_to(self, targetObj):
    if targetObj in (self, None):
      return
    
    if targetObj == self.pDrawOnObj or targetObj == self.pCurArriveObj:
      # up to the level
      if isinstance(targetObj, Door):
        gWorldEdit.upToTheLevel()
      # move to parent of linked gate
      elif isinstance(targetObj, Gate):
        self.move_to_ParentOfLinkedGate(targetObj)
      # enter the level
      else:
        gWorldEdit.setCurrentLevel(targetObj)
    else:
      # move to lower position of target, little offset
      self.move(targetObj.getOffsetPos(), targetObj)
  
  # move to parent of linked gate
  def move_to_ParentOfLinkedGate(self, pTargetGate):
    linkedGate = gBridge.getLinkedGate(pTargetGate)
      
    # move to the linkedGate
    bShowMoveAnimation = False
    if linkedGate and not bShowMoveAnimation:
      # immediately move
      # change parent and move to the targetPos
      self.change_parentObj(linkedGate.parentObj)
      gWorldEdit.setCurrentLevel(linkedGate.parentObj)
      # arrived process...
      self.setPos(linkedGate.getOffsetPos())
      self.pCurArriveObj = linkedGate
      self.pTargetObj = None
      self.pStartFromObj = None
    # if not found linked gate then Find linked Obj with parent of gate
    else:
      linkedObj = gBridge.getLinkedObjWithGate(pTargetGate)
      gWorldEdit.upToTheLevel()
      self.move_to(linkedObj)

  def stop(self):
    self.bMove = False
    if self.bJump:
      self.setPos((self.pos[0], self.fFloorPos))
    self.bJump = False
      
#---------------------#
# class : World
#---------------------#
class World(BaseObject, Singleton):
  childTypes = ["City", "Player"]
  name = "Kivy"
    
#---------------------#
# class : City
#---------------------#
class City(BaseObject):
  namelistFile = "city_names.txt"
  childTypes = ["Dungeon", "Town", "Road", "Gate", "Point", "Player"]
  icon = "city"
  bEnableBridge = True

#---------------------#
# class : Gate
#---------------------#
class Gate(BaseObject):
  icon = "arrow"
  name = "Gate"
  bDrawTypeName = False
  bEnableBridge = True
  bCreatable = False
  bMovable = False
  bDeletable = False
  bEnterPoint = True
  
#---------------------#
# class : Point
#---------------------#
class Point(BaseObject):
  icon = "point"
  name = ""
  bEnableBridge = True
  bDrawTypeName = False
  
#---------------------#
# class : Door
#---------------------#
class Door(BaseObject):
  icon = "point"
  name = ""
  bCreatable = False
  bDeletable = False
  bEnterPoint = True
  
#---------------------#
# class : Road
#---------------------#
class Road(BaseObject):
  namelistFile = "city_names.txt"
  childTypes = ["Building", "Gate", "Point", "Monster", "Npc", "Player"]
  icon = "road"
  bFreeMoveType = True
  bEnableBridge = True
  
  def postLoadProcess(self):
    # clear xml data
    BaseObject.postLoadProcess(self)
  
#---------------------#
# class : Dungeon
#---------------------#
class Dungeon(BaseObject):
  namelistFile = "city_names.txt"
  childTypes = ["Gate", "Point", "Monster", "Npc", "Player"]
  icon = "dungeon"
  bEnableBridge = True
  bFreeMoveType = False
  
#---------------------#
# class : Town
#---------------------#
class Town(BaseObject):
  namelistFile = "city_names.txt"
  childTypes = ["Building", "Point", "Gate", "Npc", "Monster", "Player"]
  icon = "town"
  bEnableBridge = True
  bFreeMoveType = False
  
#---------------------#
# class : Building
#---------------------#
class Building(BaseObject):
  namelistFile = "building_names.txt"
  bUniqueName = False
  childTypes = ["Door", "Npc", "Monster", "Player"]
  icon = "building"
  bEnableBridge = True
  bDrawTypeName = False
  bHasDoor = True
  bFreeMoveType = True

#---------------------#
# class : Monster
#---------------------#
class Monster(BaseObject):
  namelistFile = "monster_names.txt"
  icon = "monster"
  bDrawTypeName = False
  bCharacterType = True
  
  def update(self, dt):
    if hasattr(self, "anim"):
      self.anim = Animation(x=self.pos[0]+100)
      self.anim += Animation(x=self.pos[0]-200)
      self.anim.repeat = True
      self.anim.start(self)
  
#---------------------#
# class : Npc
#---------------------#
class Npc(BaseObject):
  namelistFile = "npc_names.txt"
  icon = "npc"
  bDrawTypeName = False
  bCharacterType = True

#---------------------#
# class : Player ( Singleton )
#---------------------#
class Player(BaseObject, Singleton):
  name = "Player"
  icon = "npc"
  bDrawTypeName = False
  bDrawAlways = True
  bCharacterType = True
  
  def postLoadProcess(self):
    if self.xml_data != None:
      self.nCurArriveObjID = int(self.xml_data.get("arriveObjID") or -1)
      self.nStartFromObjID = int(self.xml_data.get("startFromObjID") or -1)
      self.pCurArriveObj = gWorldEdit.getObj(self.nCurArriveObjID)
      self.pStartFromObj = gWorldEdit.getObj(self.nStartFromObjID)
    # clear xml data
    BaseObject.postLoadProcess(self)