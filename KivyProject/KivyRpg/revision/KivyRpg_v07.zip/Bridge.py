from copy import copy
from xml.etree.ElementTree import Element, dump, parse, SubElement, ElementTree

import Utility as Util
from Utility import *

from ObjectBase import Gate

#---------------------#
# Global Instance
#---------------------#
def setGlobalInstance(WorldEdit):
  global gWorldEdit
  gWorldEdit = WorldEdit.instance()
  
#---------------------#
# class : Bridge
#---------------------#
class Bridge(Singleton, Widget):
  bridgeMap = {} # ex)self.bridgeMap[id1] = set([id2,...])
  def __init__(self):
    Widget.__init__(self, size=WH)
    self.bridgeMap = {} # bridgeMap[id1] = set([(id2, gate), ...])
    
  def load(self, parentTree):
    if parentTree != None:
      xml_tree = parentTree.find( self.__class__.__name__)
      if xml_tree != None:
        linkedData = xml_tree.findall("link")
        for link in linkedData:
          # loading progress
          gMyRoot.increaseLoading()
          id1 = int(link.get("id"))
          linkedIDList = eval(link.get("linkedIDList"))
          self.bridgeMap[id1] = linkedIDList
          
  def save(self, parentTree, counter):
    className = self.__class__.__name__
    xml_data = SubElement(parentTree, className)
    counter.value += len(self.bridgeMap)
    for id1 in self.bridgeMap:
      link = SubElement(xml_data, "link")
      link.set("id", str(id1))
      link.set("linkedIDList", str(self.bridgeMap[id1]))
  
  def remove(self):
    # clear
    self.canvas.clear()
    for child in self.canvas.children:
      self.canvas.remove(child)
    
    self.bridgeMap = {}   
    # detach self
    if self.parent:
      self.parent.remove_widget(self)
      
  def draw(self):
    gWorldEdit.gameScreen.add_to_bg(self)
  
  def drawBridge(self):
    self.canvas.clear()
    for child in self.canvas.children:
      self.canvas.remove(child)
    children = copy(gWorldEdit.getCurrentLevel().get_childObj())
    childrenID = [child.getID() for child in children]
    while childrenID:
      id1 = childrenID.pop()
      if id1 in self.bridgeMap:
        for id2 in self.bridgeMap[id1]:
          if id2 in childrenID:
            obj1 = gWorldEdit.getObj(id1)
            obj2 = gWorldEdit.getObj(id2)
            if obj1 and obj2:
              # draw bridge
              with self.canvas:
                Color(1,1,1,0.5)
                Line(points = obj1.center + obj2.center, width = 10)
              # recalc gate pos
              if id1 in self.bridgeMap and id2 in self.bridgeMap[id1]:
                gate1 = gWorldEdit.getObj(self.bridgeMap[id1][id2])
                self.calcGatePos(gate1, obj1, obj2)
              if id2 in self.bridgeMap and id1 in self.bridgeMap[id2]:
                gate2 = gWorldEdit.getObj(self.bridgeMap[id2][id1])
                self.calcGatePos(gate2, obj2, obj1)
  
  def hasBridge(self, obj):
    return obj and (obj.getID() in self.bridgeMap)
                      
  def isLinked(self, obj1, obj2):
    if obj1 and obj2 and obj1 is not obj2:
      id1 = obj1.getID()
      id2 = obj2.getID()
      if id1 in self.bridgeMap and id2 in self.bridgeMap and \
        id1 in self.bridgeMap[id2] and id2 in self.bridgeMap[id1]:
        return True
    return False
    
  def breakLink(self, obj1):
    if obj1:
      id1 = obj1.getID()
      if id1 in self.bridgeMap:
        linkedIDList = copy(self.bridgeMap[id1])
        for id2 in linkedIDList:
          self.removeBridge(obj1, gWorldEdit.getObj(id2))
  
  def calcGatePos(self, gate, obj1, obj2):
    if gate and obj1 and obj2:
      vDir = normalize(sub(obj2.center, obj1.center))
      if vDir[1] == 0.0 or abs(vDir[0]/vDir[1]) > W/H:
        # left or right direction
        vDir = mul(vDir, abs(W * 0.4 / vDir[0]))
      else:
        # top or bottom.direction
        vDir = mul(vDir, abs(H * 0.3 / vDir[1]))
      gate.center = add(mul(cXY, (1.0, 0.95)), vDir)
     
  def addBridge(self, obj1, obj2):
    if obj1 and obj2 and obj1 is not obj2:
      def setLink(obj1, obj2):
        id1 = obj1.getID()
        id2 = obj2.getID()
        # add new gate
        gate = obj1.add_childObj("Gate")
        gateID = -1
        # set gate name and pos
        if gate:
          gateID = gate.getID()
          gate.setName(obj2.getName() + " Gate")
          self.calcGatePos(gate, obj1, obj2)   
        # add new bridge item - (id2, gate)
        if id1 in self.bridgeMap:
          self.bridgeMap[id1][id2] = gateID
        else:
          self.bridgeMap[id1] = { id2:gateID }
      setLink(obj1, obj2)
      setLink(obj2, obj1)
      # add line
      if gWorldEdit.getCurrentLevel() == obj1.parentObj:
        with self.canvas:
          Color(1,1,1,0.5)
          Line(points = obj1.center + obj2.center, width = 10)   
        
  def removeBridge(self, obj1, obj2):
    if obj1 and obj2 and obj1 is not obj2:
      if self.isLinked(obj1, obj2):
        id1 = obj1.getID()
        id2 = obj2.getID()
        # remove gate and pop bridge
        if id2 in self.bridgeMap and id1 in self.bridgeMap[id2]:
          gate1 = gWorldEdit.getObj(self.bridgeMap[id2].pop(id1))
          gate1 and gate1.remove()
        if id1 in self.bridgeMap and id2 in self.bridgeMap[id1]:
          gate2 = gWorldEdit.getObj(self.bridgeMap[id1].pop(id2))
          gate2 and gate2.remove()
        # pop empty map item
        if not self.bridgeMap[id1]:
          self.bridgeMap.pop(id1)
        if not self.bridgeMap[id2]:
          self.bridgeMap.pop(id2)
      self.drawBridge()
  
  # Bridge method
  def checkBridge(self, obj1, obj2):
    if obj1 and obj2 and obj1 is not obj2 and obj1.bEnableBridge and obj2.bEnableBridge:
      if self.isLinked(obj1, obj2):
        self.removeBridge(obj1, obj2)
      else:
        self.addBridge(obj1, obj2)