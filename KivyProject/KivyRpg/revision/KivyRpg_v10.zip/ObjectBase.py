from copy import copy
from xml.etree.ElementTree import Element, dump, parse, SubElement, ElementTree

import Utility as Util
from Utility import *
from kivy.animation import Animation
from ResourceMgr import gResMgr

from Globals import *

#---------------------#
# Global Variable
#---------------------#
icon_size = WRect(0.1)

autoCreateList = ["Gate", "Door"]
gFreeMoveType = ["Building", "Town", "Road"]
gGateType = ["Gate", "Door"]
gCharacterType = ["Player", "Npc", "Monster"]

#---------------------#
# Global Instance
#---------------------#
def setGlobalInstance(WorldEdit, Bridge):
  global gWorldEdit
  global gBridge
  global gPlayer
  gWorldEdit = WorldEdit.instance()
  gBridge = Bridge.instance()
  gPlayer = Player.instance()
  
#---------------------#
# class : ObjectBase
#---------------------#
class BaseObject(Scatter, StateMachine):
  ID = -1
  namelistFile = ""
  namelist = []
  name = "No name"
  icon = ""
  label = None
  label_id = None
  bUniqueName = True
  bDrawTypeName = True
  parentObj = None
  childTypes = []
  childObj = []
  bTouched = False
  bMovable = True
  bDeletable = True
  bEnableBridge = False
  bRedrawBridge = False
  bDrawAlways = False
  pDrawOnObj = None

  # transform method
  curPos = None # real position, pos is relative position
  bJump = False
  fJump = False
  bMove = False
  vStartPos = None
  vTargetPos = None
  pTargetObj = None
  pStartFromObj = None
  nStartFromObjID = -1
  pCurArriveObj = None
  nCurArriveObjID = -1
  vMoveDir = None
  fMoveTime = 0.0
  fMoveTimeAcc = 0.0
  fFloorPos = 0.0
    
  def __init__(self):
    # class method - load name library
    self.loadNamelist()
    
    # state machine init
    StateMachine.__init__(self)

    # init scatter
    Scatter.__init__(self, size=icon_size)
    self.setPos(cXY)
    self.do_translation = self.bMovable
    self.do_rotation = False
    self.do_scale = False
    self.auto_bring_to_front = False
    
    # set box region
    with self.canvas:
      self.boxColor = Color(0.7,0.7,1.0,0.0)
      Rectangle(size=self.size)
      Color(1,1,1)
      self.box = Rectangle(size=self.size)   
    
    # attach name label
    self.label = Label(text=self.name, center=mul(self.size, (0.5, 1.0)))
    self.label.pos[1] += self.label.size[1] * 0.1
    self.add_widget(self.label)
    
    # attach id label
    self.label_id = Label(text="-1", center=mul(self.size, (0.5, 1.0)))
    self.label_id.pos[1] = self.label.pos[1] + self.label.size[1] * 0.5
    
    # bind func
    self.bind(on_touch_down = self.touch_down,
      on_touch_move = self.touch_move,
      on_touch_up = self.touch_up)
      
  def setPos(self, pos):
    self.pos = copy(pos)
    self.curPos = copy(pos)
    
  def getPos(self): return self.pos
  def getOffsetPos(self): return sub(self.pos, (0.0, self.size[1]*0.25))
  def getCurPos(self): return self.curPos
  def getCurOffsetPos(self): return sub(self.curPos, (0.0, self.size[1]*0.25))
  def setMovable(self, bMovable):
   self.bMovable = bMovable
   self.do_translation = bMovable
  def isMove(self): return self.bMove
  def isJump(self): return self.bJump
  
  def getType(self):
    return self.__class__.__name__
 
  # reset data  
  def reset(self, parentObj, xml_data):
    if self == parentObj:
      return
    #init data
    self.parentObj = parentObj
    self.childObj = []
    self.bTouched = False
    self.bRedrawBridge = False
    self.bMove = False
    self.bJump = False
    self.fJump = 0.0
    self.vStartPos = [0,0]
    self.vTargetPos = [0,0]
    self.pTargetObj = None
    self.pStartFromObj = None
    self.nStartFromObjID = -1
    self.pCurArriveObj = None
    self.nCurArriveObjID = -1
    self.pDrawOnObj = None
    self.vMoveDir = [0,0]
    self.fMoveTime = 0.0
    self.fMoveTimeAcc = 0.0
    
    # set icon
    if self.icon:
      self.box.texture = gResMgr.getTex(self.icon)
        
    # set loading data
    if xml_data == None:
      self.setNewName(self)
      self.setID(-1)
      self.setPos(cXY)
      # add door
      if self.__class__.__name__ == "Building":
        door = self.add_childObj("Door")
        door.center = mul(WH, (0.5, 0.15))
        door.setPos(door.pos)
    else:
      def loadObjID(key):
        id = xml_data.get(key)
        if id != None and id > 0:
          gWorldEdit.addPostLoadProcess(self)
          return int(id)
      self.setID(int(xml_data.get("id")))
      self.setName(xml_data.get("name"))
      self.setPos(eval(xml_data.get("pos")))
      self.nCurArriveObjID = loadObjID("arriveObjID")
      self.nStartFromObjID = loadObjID("startFromObjID")
        
    # set floor pos
    self.fFloorPos = self.getCurPos()[1]
    # add to worldedit
    if self.bDrawAlways:
      gWorldEdit.addDrawAlwaysObj(self)
    # regist object
    gWorldEdit.registObjID(self)
  
  def remove(self):
    if not self.bDeletable and gWorldEdit.getCurrentLevel() == self.parentObj:
      return False
    # deleted log
    #log(" ".join(["Removed", self.getType(), ":", self.getTitle()]))
      
    # recursive
    childObj = copy(self.childObj)
    for child in childObj:
      child.remove()
    
    # movement stop 
    self.stop()
    
    # break link
    if isinstance(self, Gate) and isinstance(self.parentObj, Road):
      gBridge.breakLink(gBridge.getParentOfGate(self))
    else:
      # maybe.. I have gate. cause try to break link
      gBridge.breakLink(self)
    
    # pop my widget from parent 
    if self.parent:
      self.parent.remove_widget(self)
      
    # pop self from parent
    if self.parentObj:
      self.parentObj.pop_childObj(self)  
    self.parentObj = None
    
    # unregist
    gWorldEdit.unregistObjID(self)
    return True
    
  @classmethod
  def loadNamelist(cls):
    if cls.namelistFile and not cls.namelist:
      filepath = os.path.join("data", cls.namelistFile)
      if os.path.isfile(filepath):
        f = open(filepath, "r")
        cls.namelist = map(lambda x:x.strip(), list(f))
        f.close()    
  
  @classmethod
  def setNewName(cls, obj):
    if cls.namelist and len(cls.namelist) > 0:
      name = random.choice(cls.namelist).strip()
      obj.setName(name)
    else:
      # set default name
      obj.setName(cls.name)
  
  @classmethod
  def checkName(cls, objName):
    '''if is there name then remove..'''
    if cls.bUniqueName and objName in cls.namelist:
      cls.namelist.remove(objName)
      
  def setName(self, name):
    self.name = name
    self.label.text = self.getTitle()
    self.checkName(self.name)
    
  def getName(self):
    return self.name
  
  def getTitle(self):
    if self.bDrawTypeName:
      return self.name + " " + self.__class__.__name__
    else:
      return self.name
  
  def getID(self):
    return self.ID 
    
  def setID(self, ID):
    self.ID = ID
    self.label_id.text = "ID : " + str(self.ID)
    
  def draw(self):
    # check, is valid object?
    if self.getID() == -1:
      return
    # pop.from.old.parent
    if self.parent != None:
      self.parent.remove_widget(self)
    # calc pos
    self.pDrawOnObj = None
    if self.bDrawAlways:
      # draw to current position
      if self.parentObj == gWorldEdit.getCurrentLevel():
        self.pos = copy(self.curPos)
      # draw to parent position
      elif self.parentObj != None:
        prevParentObj = self.parentObj
        parentObj = self.parentObj.parentObj
        while parentObj:
          if gWorldEdit.getCurrentLevel() == parentObj:
            self.pos = prevParentObj.getCurOffsetPos()
            self.pDrawOnObj = prevParentObj
            break
          prevParentObj = parentObj
          parentObj = parentObj.parentObj
        else:
          # currentLevel not matched parent level, cause do not draw.
          return
    # add to parent
    gWorldEdit.gameScreen.add_to_bg(self)
    # show id
    self.showID(gWorldEdit.isEditMode)
    
  # Display ID 
  def showID(self, bShow):
    if not self.label_id:
      return
    # toggle id label
    if bShow:
      if not self.label_id.parent:
        self.add_widget(self.label_id)
    elif self.label_id.parent:
      self.remove_widget(self.label_id)     
  
  def load(self, parentTree):
    xml_data = parentTree.find(self.__class__.__name__)\
      if parentTree != None else None
    # loading progress
    gMyRoot.increaseLoading()
    self.reset(None, xml_data)
    self.load_child(xml_data)
      
  def load_child(self, currentTree):
    # load child data
    if currentTree != None:   
      # loading progress
      gMyRoot.increaseLoading()
      for childType in self.childTypes:
        xml_tree = currentTree.findall(childType)
        if xml_tree != None:
          for xml_data in xml_tree:
            child = self.add_childObj(childType, xml_data)
            child.load_child(xml_data)
  
  def postLoadProcess(self):
    self.pCurArriveObj = gWorldEdit.getObj(self.nCurArriveObjID)
    self.pStartFromObj = gWorldEdit.getObj(self.nStartFromObjID)
  
  def save(self, parentTree, counter):
    counter.value += 1
    className = self.__class__.__name__
    if parentTree == None:
      xml_data = Element(className)
    else:
      xml_data = SubElement(parentTree, className)
    xml_data.set("id", str(self.getID()))
    xml_data.set("name", self.name)
    xml_data.set("pos", str(self.getCurPos()))
    if self.pCurArriveObj:
      xml_data.set("arriveObjID", str(self.pCurArriveObj.getID()))
    if self.pStartFromObj:
      xml_data.set("startFromObjID", str(self.pStartFromObj.getID()))
      
    for child in self.childObj:
      child.save(xml_data, counter)
    return xml_data
    
  def isTouched(self):
    return self.bTouched
    
  def append_childObj(self, childObj):
    self.childObj.append(childObj)
   
  def add_childObj(self, childType, xml_data = None):
    if childType in self.childTypes:
      childClass = eval(childType)
      child = None
      # check singleton
      if hasattr(childClass, "instance"):
        # pop from parent
        child = childClass.instance()
        if child.parentObj:
          child.parentObj.pop_childObj(child)
        
        if child.getID() == -1:
          # when loaded...
          child.reset(self, xml_data)
        else:
          # set new parent
          child.set_parentObj(self)
      else:
        # add new child object or loaded
        child = childClass()
        child.reset(self, xml_data)
      self.append_childObj(child)
      if gWorldEdit.getCurrentLevel() == self:
        child.draw()
      return child
  
  # clear    
  def clear(self):
    childObj = copy(self.childObj)
    for child in childObj:
      child.remove()
      
  def getChildTypes(self):
    return self.childTypes
  
  def get_childObj(self):
    return self.childObj
    
  def pop_childObj(self, obj):
    obj.parentObj = None
    if obj in self.childObj:
      # pop obj from childObj
      self.childObj.remove(obj)
    # pop from parent widget
    if obj.parent:
      obj.parent.remove_widget(obj)
    
  def draw_childObj(self):
    for child in self.childObj:
      child.draw()
  
  def get_parentObj(self):
    return self.parentObj
  
  def set_parentObj(self, parentObj):
    self.parentObj = parentObj
    
  def change_parentObj(self, newParentObj):
    if newParentObj != None and newParentObj != self.parentObj and \
      self.getType() in newParentObj.getChildTypes():
        if self.parentObj:
          self.parentObj.pop_childObj(self)
        self.set_parentObj(newParentObj)
        newParentObj.append_childObj(self)
        # set real position ( curPos )
        self.setPos(self.getPos())
        # draw
        if self.bDrawAlways or gWorldEdit.getCurrentLevel() == newParentObj:
          self.draw()
          
  def findGate(self, vMoveDir):
    #log("find gate")
    vMoveDir = normalize(mul(vMoveDir, (0.8,0.6)))
    #find best gate....
    maxDot = -1.0
    gateObj = None
    for child in self.childObj:
      if child.getType() in gGateType:
        vDir = sub(mul(cXY, (1.0, 0.95)), child.center)
        vDir = normalize(vDir)
        curDot = dot(vDir, vMoveDir)
        if curDot > maxDot:
          maxDot = curDot
          gateObj = child
          #log(gateObj.getName() + " " + str(curDot))
    return gateObj
      
  # on enter or exit to other level
  def exitLevel(self, depth = 0):
    if depth == 0:
      for child in self.childObj:
        child.exitLevel(depth+1)
    self.pDrawOnObj = None
  
  def showPopup(self, *args):
    gWorldEdit.popupMenu.showPopup(self)
 
  def touch_down(self, inst, touch):
    self.do_translation = gWorldEdit.isEditMode and self.bMovable
    if self.collide_point(*touch.pos):
      # for select only one object
      if not gWorldEdit.isEditMode:
        dist = getDist(self.center, touch.pos)
        touchObj, touchDist = gWorldEdit.getTouchObj()
        if touchObj != None and touchObj != self:
          if touchDist < dist:
            return
          else:
            touchObj.touch_up(inst, touch, True)
        gWorldEdit.setTouchObj(self, dist)
      
      # set touch
      self.bTouched = True
      # touch flag - check touch something? by gWorldEdit
      touch.bTouched = True
      touch.grab(self)
      # set select obj
      gWorldEdit.selectObj(self)
      # set selected color
      self.boxColor.a = 0.3  
      # check edit
      if gWorldEdit.isEditMode:
        self.bRedrawBridge = False
        # set delete callback
        if self.bDeletable:
          Clock.schedule_once(self.showPopup, 0.3)
        # double tap - enter the level
        if touch.is_double_tap:
          gWorldEdit.setCurrentLevel(self)

  def touch_move(self, inst, touch):
    if self == touch.grab_current:
      if gWorldEdit.isEditMode:
        self.bRedrawBridge = True
      Clock.unschedule(self.showPopup)
      
  def touch_up(self, inst, touch, bForce=False):
    if self == touch.grab_current or bForce:
      if gWorldEdit.getTouchObj()[0] == self:
        gWorldEdit.setTouchObj(None, 0.0)
      self.bTouched = False
      touch.ungrab(self)
      self.boxColor.a = 0.0
      Clock.unschedule(self.showPopup)
      # edit mode
      if gWorldEdit.isEditMode:
        # redraw bridge
        if self.bRedrawBridge:
          self.bRedrawBridge = False
          if gBridge.hasBridge(self):
            gBridge.drawBridge()
        # set pos
        if self.parentObj == gWorldEdit.getCurrentLevel():
          self.setPos(self.pos)
        
  def checkInRegion(self):
    x, y = self.getPos()
    if x < W * 0.2:
      x = W * 0.2
    elif x + self.size[0] > W * 0.8:
      x = W * 0.8 - self.size[0]
    if y < H * 0.2:
      y = H * 0.2
    elif y + self.size[1] > H * 0.8:
      y = H * 0.8 - self.size[1]
    self.pos = (x,y)
    
  # update
  def update(self, dt):
    if self.bMove or self.bJump:
      self.updateMove(dt)
    
  # move method 
  def updateMove(self, dt):
    pos = self.getPos()
    # move
    if self.bMove:
      pos = add(pos, mul(self.vMoveDir, gWalk * dt))
      self.fMoveTimeAcc += dt
      if self.fMoveTimeAcc >= self.fMoveTime:
        self.bMove = False
        self.fMoveTime = 0.0
        self.fMoveTimeAcc = 0.0
        if self.bJump:
          pos = (self.vTargetPos[0], pos[1])
        else:
          pos = copy(self.vTargetPos)
      ratio = self.fMoveTimeAcc / self.fMoveTime if self.fMoveTime > 0.0 else 1.0
      ratio = min(1.0, max(0.0, ratio))
      self.fFloorPos = self.vStartPos[1] * (1.0-ratio) + self.vTargetPos[1]*ratio
      self.jump()
      
    # jump
    if self.bJump:
      self.fJump -= gGravity * dt
      pos = add(pos, (0.0, self.fJump * dt))
      if self.fJump <= 0.0 and self.getPos()[1] <= self.fFloorPos:
        pos = (pos[0], self.fFloorPos)
        self.bJump = False
        
    # set position
    self.setPos(pos)
    
    # check arrived to the target
    if not self.bMove and not self.bJump:
      self.arrivedAt()
      
  def getTargetObj(self):
    return self.pTargetObj
     
  def arrivedAt(self):
    self.stop()
    if self == gPlayer and self.pTargetObj != None:
      # up to level
      if isinstance(self.pTargetObj, Door):
        gWorldEdit.upToTheLevel()
      # move to the parent of linked gate
      elif isinstance(self.pTargetObj, Gate):
        #check linked obj count - if gate has many linked obj, stop for user choose
        # will be return. so you must set arrive obj in below method
        self.move_to_ParentOfLinkedGate(self.pTargetObj)
        return
      # enter the level
      elif self.getType() in self.pTargetObj.getChildTypes():
        # change parent
        self.change_parentObj(self.pTargetObj)
        gWorldEdit.setCurrentLevel(self.pTargetObj)
        self.pTargetObj = self.pTargetObj.findGate(self.vMoveDir)
        if self.pTargetObj:
          self.setPos(self.pTargetObj.getOffsetPos())
    self.pCurArriveObj = self.pTargetObj
    self.pTargetObj = None
    self.pStartFromObj = None
  
  def jump(self, force=gJump):
    if not self.bJump:
      self.bJump = True
      self.fJump = force
      if not self.bMove:
        self.fFloorPos = self.getPos()[1]
  
  def move(self, targetPos, targetObj = None        ):
    self.pTargetObj = targetObj
    dist = getDist(targetPos, self.pos)
    # check, can move?
    if dist > 0.001:
      self.bMove = True
      self.fMoveTime = dist / gWalk
      self.fMoveTimeAcc = 0.0
      self.pStartFromObj = self.pDrawOnObj or self.pCurArriveObj
      self.vStartPos = copy(self.getPos())
      self.vTargetPos = copy(targetPos)
      self.pCurArriveObj = None
      self.vMoveDir = normalize(sub(targetPos, self.pos))
      # set parent the current level
      self.change_parentObj(gWorldEdit.getCurrentLevel())
    else:
      self.arrivedAt()
     
  def move_to(self, targetObj):
    if targetObj in (self, None):
      return
      
    if targetObj == self.pDrawOnObj or targetObj == self.pCurArriveObj:
      # up to the level
      if isinstance(targetObj, Door):
        gWorldEdit.upToTheLevel()
      # move to parent of linked gate
      elif isinstance(targetObj, Gate):
        self.move_to_ParentOfLinkedGate(targetObj)
      # enter the level
      else:
        gWorldEdit.setCurrentLevel(targetObj)
    else:
      # move to lower position of target, little offset
      self.move(targetObj.getOffsetPos(), targetObj)
  
  # move to parent of linked gate
  def move_to_ParentOfLinkedGate(self, pTargetGate):
    linkedGate = gBridge.getLinkedGate(pTargetGate)
      
    # move to the linkedGate
    bShowMoveAnimation = False
    if linkedGate and not bShowMoveAnimation:
      # immediately move
      # change parent and move to the targetPos
      self.change_parentObj(linkedGate.parentObj)
      gWorldEdit.setCurrentLevel(linkedGate.parentObj)
      # arrived process...
      self.setPos(linkedGate.getOffsetPos())
      self.pCurArriveObj = linkedGate
      self.pTargetObj = None
      self.pStartFromObj = None
    # if not found linked gate then Find linked Obj with parent of gate
    else:
      linkedObj = gBridge.getLinkedObjWithGate(pTargetGate)
      gWorldEdit.upToTheLevel()
      self.move_to(linkedObj)

  def stop(self):
    self.bMove = False
    if self.bJump:
      self.setPos((self.pos[0], self.fFloorPos))
    self.bJump = False
      
#---------------------#
# class : World
#---------------------#
class World(BaseObject, Singleton):
  childTypes = ["City", "Player"]
  name = "Kivy"
    
#---------------------#
# class : City
#---------------------#
class City(BaseObject):
  namelistFile = "city_names.txt"
  childTypes = ["Dungeon", "Town", "Road", "Gate", "Point", "Player"]
  icon = "city"
  bEnableBridge = True

#---------------------#
# class : Gate
#---------------------#
class Gate(BaseObject):
  icon = "point"
  name = "Gate"
  bDrawTypeName = False
  bEnableBridge = True
  bMovable = False
  bDeletable = False
  
#---------------------#
# class : Point
#---------------------#
class Point(BaseObject):
  icon = "point"
  name = ""
  bEnableBridge = True
  
#---------------------#
# class : Door
#---------------------#
class Door(BaseObject):
  icon = "point"
  name = ""
  bDeletable = False
  
#---------------------#
# class : Road
#---------------------#
class Road(BaseObject):
  namelistFile = "city_names.txt"
  childTypes = ["Building", "Gate", "Point", "Monster", "Npc", "Player"]
  icon = "point"
  bEnableBridge = True
  
#---------------------#
# class : Dungeon
#---------------------#
class Dungeon(BaseObject):
  namelistFile = "city_names.txt"
  childTypes = ["Gate", "Point", "Monster", "Npc", "Player"]
  icon = "dungeon"
  bEnableBridge = True
  
#---------------------#
# class : Town
#---------------------#
class Town(BaseObject):
  namelistFile = "city_names.txt"
  childTypes = ["Building", "Point", "Gate", "Npc", "Monster", "Player"]
  icon = "town"
  bEnableBridge = True
  
#---------------------#
# class : Building
#---------------------#
class Building(BaseObject):
  namelistFile = "building_names.txt"
  bUniqueName = False
  childTypes = ["Door", "Npc", "Monster", "Player"]
  icon = "building"
  bEnableBridge = True
  bDrawTypeName = False

#---------------------#
# class : Monster
#---------------------#
class Monster(BaseObject):
  namelistFile = "monster_names.txt"
  icon = "monster"
  bDrawTypeName = False
    
#---------------------#
# class : Npc
#---------------------#
class Npc(BaseObject):
  namelistFile = "npc_names.txt"
  icon = "npc"
  bDrawTypeName = False

#---------------------#
# class : Player ( Singleton )
#---------------------#
class Player(BaseObject, Singleton):
  name = "Player"
  icon = "npc"
  bDrawTypeName = False
  bDrawAlways = True