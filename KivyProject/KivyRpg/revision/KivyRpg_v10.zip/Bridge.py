from copy import copy
from xml.etree.ElementTree import Element, dump, parse, SubElement, ElementTree

import Utility as Util
from Utility import *

from ObjectBase import Gate, City, Road

#---------------------#
# Global Instance
#---------------------#
def setGlobalInstance(WorldEdit):
  global gWorldEdit
  gWorldEdit = WorldEdit.instance()
  
#---------------------#
# class : Bridge
#---------------------#
class Bridge(Singleton, Widget):
  bridgeMap = {}
  gateMap = {}
  def __init__(self):
    Widget.__init__(self, size=WH)
    self.bridgeMap = {} # ex)bridgeMap[id1] = {id2:[gate1ID, gate2ID], ...}
    self.gateMap = {} # ex)gateMap[gate1id] = [gate2id, (obj1ID, obj2ID)]
    
  def load(self, parentTree):
    if parentTree != None:
      xml_tree = parentTree.find( self.__class__.__name__)
      if xml_tree != None:
        _from = xml_tree.findall("from")
        for obj1 in _from:
          # loading progress
          gMyRoot.increaseLoading()
          id1 = int(obj1.get("id"))
          _toList = eval(obj1.get("to"))
          self.bridgeMap[id1] = _toList
          # generate gateMap
          for id2 in _toList:
            gate1ID, gate2ID = _toList[id2]
            self.gateMap[gate1ID] = [gate2ID, (id1, id2)]
            
          
  def save(self, parentTree, counter):
    className = self.__class__.__name__
    xml_data = SubElement(parentTree, className)
    counter.value += len(self.bridgeMap)
    for id1 in self.bridgeMap:
      link = SubElement(xml_data, "from")
      link.set("id", str(id1))
      link.set("to", str(self.bridgeMap[id1]))
  
  def remove(self):
    # clear
    self.canvas.clear()
    for child in self.canvas.children:
      self.canvas.remove(child)
    
    self.bridgeMap = {}   
    # detach self
    if self.parent:
      self.parent.remove_widget(self)
      
  def draw(self):
    gWorldEdit.gameScreen.add_to_bg(self)
  
  def drawLine(self, pos1, pos2):
    # draw bridge
    with self.canvas:
      Color(1,1,1,0.5)
      Line(points = [pos1[0], pos1[1], pos2[0], pos2[1]], width = 10)
  
  def drawBridge(self):
    # clear drawn bridge
    self.canvas.clear()
    for child in self.canvas.children:
      self.canvas.remove(child)
    # make draw bridge list
    children = copy(gWorldEdit.getCurrentLevel().get_childObj())
    childrenID = [child.getID() for child in children]
    # start draw linked bridges
    while childrenID:
      id1 = childrenID.pop()
      if id1 in self.bridgeMap:
        # check linked obj2 with obj1
        for id2 in self.bridgeMap[id1]:
          obj1 = gWorldEdit.getObj(id1)
          obj2 = gWorldEdit.getObj(id2)
          if obj1 and obj2:
            if id2 in childrenID:
              # draw bridge line
              self.drawLine(obj1.center, obj2.center)
              # recalculate gate1 pos
              if id1 in self.bridgeMap and id2 in self.bridgeMap[id1]:
                gate1 = gWorldEdit.getObj(self.bridgeMap[id1][id2][0])
                if gate1:
                  self.calcGatePos(gate1, obj1, obj2)
                  # recalc Road Obj pos
                  if isinstance(gate1.parentObj, Road) and isinstance(obj1, City) and isinstance(obj2, City):
                    self.calcGatePos(gate1.parentObj, obj1, obj2)
              # recalculate gate2 pos
              if id2 in self.bridgeMap and id1 in self.bridgeMap[id2]:
                gate2 = gWorldEdit.getObj(self.bridgeMap[id2][id1][0])
                if gate2:
                  self.calcGatePos(gate2, obj2, obj1)
                  # recalc Road obj pos
                  if isinstance(gate2.parentObj, Road) and isinstance(obj1, City) and isinstance(obj2, City):
                    self.calcGatePos(gate2.parentObj, obj2, obj1)
        # end of For statement
    # end of draw linked bridges
    
    # draw single path bridge
    for obj in gWorldEdit.getCurrentLevel().get_childObj():
      if type(obj) in (Gate, Road):
        self.drawLine(obj.center, add(obj.center, sub(obj.center, cXY)) ) 
          
  def getParentOfGate(self, gate):
    if gate.getID() in self.gateMap:
      parentOfGate = self.gateMap[gate.getID()][1][0]
      return gWorldEdit.getObj(parentOfGate)
    return None
    
  def getLinkedGate(self, gate):
    if gate.getID() in self.gateMap:
      otherGateID = self.gateMap[gate.getID()][0]
      return gWorldEdit.getObj(otherGateID)
    return None
  
  def getLinkedObjWithGate(self, gateObj):
    gateID = gateObj.getID()
    if gateID in self.gateMap:
      obj2ID = self.gateMap[gateID][1][1]
      return gWorldEdit.getObj(obj2ID)
    return None
    
  def hasBridge(self, obj):
    return obj and (obj.getID() in self.bridgeMap)
                      
  def isLinked(self, obj1, obj2):
    if obj1 and obj2 and obj1 is not obj2:
      id1 = obj1.getID()
      id2 = obj2.getID()
      if id1 in self.bridgeMap and id2 in self.bridgeMap and \
        id1 in self.bridgeMap[id2] and id2 in self.bridgeMap[id1]:
        return True
    return False
    
  def breakLink(self, obj1):
    if obj1:
      id1 = obj1.getID()
      if id1 in self.bridgeMap:
        linkedIDList = copy(self.bridgeMap[id1])
        for id2 in linkedIDList:
          self.removeBridge(obj1, gWorldEdit.getObj(id2))
  
  def calcGatePos(self, gate, obj1, obj2):
    wRatio = 0.4
    hRatio = 0.3
    offset = (1.0, 0.9)
    
    if gate and obj1 and obj2:
      vDir = normalize(sub(obj2.center, obj1.center))
      if vDir[1] == 0.0 or abs(vDir[0]/vDir[1]) > (W*wRatio)/(H*hRatio):
        # left or right direction
        if vDir[0] != 0.0:
          vDir = mul(vDir, abs(W * wRatio / vDir[0]))
      else:
        # top or bottom.direction
        if vDir[1] != 0.0:
          vDir = mul(vDir, abs(H * hRatio / vDir[1]))
      gate.center = add(mul(cXY, offset), vDir)
     
  def addBridge(self, obj1, obj2):
    if obj1 and obj2 and obj1 is not obj2:
      def addGate(obj1, obj2):
        id1 = obj1.getID()
        id2 = obj2.getID()
        
        gate = None
        gateID = -1
        road = None
        
        if isinstance(obj1, City):
          # first, add road and add gate
          road = obj1.add_childObj("Road")
          road.setMovable(False)
          self.calcGatePos(road, obj1, obj2)
          gate = road.add_childObj("Gate")
        else:
          # add new gate
          gate = obj1.add_childObj("Gate")
          
        if gate:
          gateID = gate.getID()
          gate.setName(obj2.getTitle())
          self.calcGatePos(gate, obj1, obj2)
        return road, gate, gateID
        
      # create gates
      road1, gate1, gate1ID = addGate(obj1, obj2)
      road2, gate2, gate2ID = addGate(obj2, obj1)
      
      # if parent of gate is road, rename gate.
      if road1 and road2:
        gate1.setName("\n".join([obj2.getTitle(), road2.getTitle(), ""]))
        gate2.setName("\n".join([obj1.getTitle(), road1.getTitle(), ""]))
      
      # add new bridge item - { id2:[gate1id, gate2id],... }
      id1 = obj1.getID()
      id2 = obj2.getID()
      
      # bridgeMap
      if id1 in self.bridgeMap:
        self.bridgeMap[id1][id2] = [gate1ID, gate2ID]
      else:
        self.bridgeMap[id1] = { id2:[gate1ID, gate2ID] }
        
      if id2 in self.bridgeMap:
        self.bridgeMap[id2][id1] = [gate2ID, gate1ID]
      else:
        self.bridgeMap[id2] = { id1:[gate2ID, gate1ID] }
        
      # gateMap
      self.gateMap[gate1ID] = [gate2ID, (id1, id2)] #if not isinstance(obj2, Gate) else obj2.getID()
      self.gateMap[gate2ID] = [gate1ID, (id2, id1)] #if not isinstance(obj1, Gate) else obj1.getID()
         
      # add line
      if gWorldEdit.getCurrentLevel() == obj1.parentObj:
        with self.canvas:
          Color(1,1,1,0.5)
          Line(points = obj1.center + obj2.center, width = 10)   
        
  def removeBridge(self, obj1, obj2):
    if obj1 and obj2 and obj1 is not obj2:
      if self.isLinked(obj1, obj2):
        id1 = obj1.getID()
        id2 = obj2.getID()
        # remove gate and pop bridge
        def removeGate_popBridge(id1, id2):
          # remove gate
          if id1 in self.bridgeMap and id2 in self.bridgeMap[id1]:
            gate1ID = self.bridgeMap[id1].pop(id2)[0]
            gate1 = gWorldEdit.getObj(gate1ID)
            if gate1:
              # pop gate id from gateMap
              if gate1ID in self.gateMap:
                self.gateMap.pop( gate1ID )
             
              # if parent of gate is Road, remove Road
              # remove gate and road
              if isinstance(gate1.parentObj, Road):
                obj1 = gWorldEdit.getObj(id1)
                obj2 = gWorldEdit.getObj(id2)
                # if Road made by City, remove road
                if isinstance(obj1, City) and isinstance(obj2, City):
                  gate1.parentObj.remove()
              else:
                # remove only.gaye
                gate1.remove()
              
          # pop empty map item
          if id1 in self.bridgeMap and not self.bridgeMap[id1]:
            self.bridgeMap.pop(id1)
        # do it...
        removeGate_popBridge(id1, id2)
        removeGate_popBridge(id2, id1)
      self.drawBridge()
  
  # Bridge method
  def checkBridge(self, obj1, obj2):
    if obj1 and obj2 and obj1 is not obj2 and obj1.bEnableBridge and obj2.bEnableBridge:
      if self.isLinked(obj1, obj2):
        self.removeBridge(obj1, obj2)
      else:
        self.addBridge(obj1, obj2)