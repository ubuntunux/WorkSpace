from copy import copy
from xml.etree.ElementTree import Element, dump, parse, SubElement, ElementTree

import Utility as Util
from Utility import *
from ResourceMgr import gResMgr

from Globals import *
import time
#---------------------#
# Global Variable
#---------------------#
icon_size = WRect(0.1)
autoCreateList = ["Gate", "Door"]

#---------------------#
# Global Instance
#---------------------#
def setGlobalInstance(WorldEdit, Bridge):
  global gWorldEdit
  global gBridge
  gWorldEdit = WorldEdit.instance()
  gBridge = Bridge.instance()

#---------------------#
# decorator
#---------------------#
def popupTouch(func):
  def decorator(self, *args):
    self.clearPopup()
    func(self, *args)
  return decorator
  
#---------------------#
# class : ObjectBase
#---------------------#
class BaseObject(Scatter):
  ID = -1
  namelistFile = ""
  namelist = []
  name = "No name"
  icon = ""
  label = None
  label_id = None
  bUniqueName = True
  parentObj = None
  childTypes = []
  childObj = []
  popupRect = [0,0,0,0]
  bShowPopup = False
  widgetSize = None
  widgets = None
  nameTag = None
  bTouched = False
  bMovable = True
  bDeletable = True
  bEnableBridge = False
  bRedrawBridge = False
  
  def __init__(self):
    # class method - load name library
    self.loadNamelist()

    # init scatter
    Scatter.__init__(self, size=icon_size)
    self.pos = cXY
    self.do_translation = self.bMovable
    self.do_rotation = False
    self.do_scale = False
    self.auto_bring_to_front = False
    
    # set box region
    with self.canvas:
      self.boxColor = Color(0.7,0.7,1.0,0.0)
      Rectangle(size=self.size)
      Color(1,1,1)
      self.box = Rectangle(size=self.size)   
    
    # attach name label
    self.label = Label(text=self.name, center=mul(self.size, (0.5, 1.0)))
    self.label.pos[1] += self.label.size[1] * 0.1
    self.add_widget(self.label)
    
    # attach id label
    self.label_id = Label(text="-1", center=mul(self.size, (0.5, 1.0)))
    self.label_id.pos[1] = self.label.pos[1] + self.label.size[1] * 0.5
    
    # bind func
    self.bind(on_touch_down = self.touch_down,
      on_touch_move = self.touch_move,
      on_touch_up = self.touch_up)
 
  # reset data  
  def reset(self, parentObj, xml_data):
    if self == parentObj:
      return
    #init data
    self.parentObj = parentObj
    self.childObj = []
    self.bTouched = False
    self.bRedrawBridge = False
    
    # set icon
    if self.icon:
      self.box.texture = gResMgr.getTex(self.icon)
        
    # set loading data
    if xml_data == None:
      self.setNewName(self)
      self.setID(-1)
      self.pos = cXY
      # add door
      if self.__class__.__name__ == "Building":
        door = self.add_childObj("Door")
        door.center = mul(WH, (0.5, 0.1))
    else:
      self.setID(int(xml_data.get("id")))
      self.setName(xml_data.get("name"))
      self.pos = eval(xml_data.get("pos"))
    # regist object
    gWorldEdit.registObjID(self)
  
  def remove(self):
    if not self.bDeletable and gWorldEdit.getCurrentLevel() == self.parentObj:
      return False
      
    # remove popup menu
    self.removePopup()
      
    # recursive
    childObj = copy(self.childObj)
    for child in childObj:
      child.remove()
    
    # break link
    gBridge.breakLink(self)
    
    # pop my widget from parent 
    if self.parent:
      self.parent.remove_widget(self)
      
    # pop self from parent
    if self.parentObj:
      self.parentObj.pop_childObj(self)  
    self.parentObj = None
    
    # unregist
    gWorldEdit.unregistObjID(self)
    
    return True
    
  @classmethod
  def loadNamelist(cls):
    if cls.namelistFile and not cls.namelist:
      filepath = os.path.join("data", cls.namelistFile)
      if os.path.isfile(filepath):
        f = open(filepath, "r")
        cls.namelist = map(lambda x:x.strip(), list(f))
        f.close()    
  
  @classmethod
  def setNewName(cls, obj):
    if cls.namelist and len(cls.namelist) > 0:
      name = random.choice(cls.namelist).strip()
      obj.setName(name)
    else:
      # set default name
      obj.setName(cls.name)
  
  @classmethod
  def checkName(cls, objName):
    '''if is there name then remove..'''
    if cls.bUniqueName and objName in cls.namelist:
      cls.namelist.remove(objName)
      
  def setName(self, name):
    self.name = name
    self.label.text = name
    self.checkName(self.name)
    
  def getName(self):
    return self.name
  
  def getTitle(self):
    return self.__class__.__name__ + " - " + self.name
  
  def getID(self):
    return self.ID 
    
  def setID(self, ID):
    self.ID = ID
    self.label_id.text = "ID : " + str(self.ID)
    
  def draw(self):
    gWorldEdit.gameScreen.add_to_bg(self)
    # show id
    self.showID(gWorldEdit.isEditMode)
  
  @popupTouch
  def rename(self, inst):
    self.setName(inst.text)
  
  @popupTouch
  def removeDialog(self):
    def funcRemove():
      self.remove()
      gWorldEdit.notifyRemoveObj(self)
    gMyRoot.popup("Remove?", funcRemove, None)
    
  @popupTouch
  def nothing(self):
    pass
    
  # popup menu method
  def initPopup(self):
    self.bShowPopup = False
    self.widgetSize = mul(WH, (0.2,0.07))
    self.widgets = []
    # name
    self.nameTag = TextInput(text = "", multiline=False, size=self.widgetSize,
        background_color=(1,1,1,0.1), foreground_color=(1,1,1,1))
    self.nameTag.bind(on_text_validate = self.rename)
    self.widgets.append(self.nameTag)
    # etc button
    btn = Button(text = "set start point", size=self.widgetSize)
    btn.bind(on_release = lambda inst:self.nothing())
    self.widgets.append(btn)
    # remove button
    btn = Button(text = "Remove", size=self.widgetSize)
    btn.bind(on_release = lambda inst:self.removeDialog())
    self.widgets.append(btn)
    # close button
    btn = Button(text = "Close", size=self.widgetSize)
    btn.bind(on_release = lambda inst:self.clearPopup())
    self.widgets.append(btn)
  
  def showPopup(self, *args):
    if self.bShowPopup != True:
      # build popup
      self.initPopup()
      self.bShowPopup = True
      self.nameTag.text = self.getName()
      # right-top
      pos = sub(add(self.pos[:2], self.size[:2]), (0, self.widgetSize[1]))
      width = self.widgetSize[0]
      height = self.widgetSize[1] * len(self.widgets)
      # check popup pos
      if (pos[1] + self.widgetSize[1]) - height < 0.0:
        pos[1] = height - self.widgetSize[1]
      if pos[0] + width > W:
        pos[0] = self.pos[0] - width
      # set popup rect
      self.popupRect = [pos[0], (pos[1]+self.widgetSize[1])-height, pos[0]+width, pos[1] + self.widgetSize[1]]
      # set pos
      for btn in self.widgets:
        gWorldEdit.gameScreen.add_to_bg(btn)
        btn.pos = pos
        pos = sub(pos, (0, self.widgetSize[1]))
      
  def clearPopup(self, *args):
    if self.bShowPopup:
      self.bShowPopup = False
      for btn in self.widgets:
        gWorldEdit.gameScreen.remove_from_bg(btn)
    self.widgets = []
    self.nameTag = None
  
  def removePopup(self):
    self.clearPopup()
    self.widgets = []
    self.nameTag = None
        
  def togglePopup(self):
    if self.bShowPopup:
      self.clearPopup()
    else:
      self.showPopup()
  
  # Display ID 
  def showID(self, bShow):
    if not self.label_id:
      return
    # toggle id label
    if bShow:
      if not self.label_id.parent:
        self.add_widget(self.label_id)
    elif self.label_id.parent:
      self.remove_widget(self.label_id)     
  
  def load(self, parentTree):
    xml_data = parentTree.find(self.__class__.__name__)\
      if parentTree != None else None
    # loading progress
    gMyRoot.increaseLoading()
    self.reset(None, xml_data)
    self.load_child(xml_data)
      
  def load_child(self, currentTree):
    # load child data
    if currentTree != None:   
      # loading progress
      gMyRoot.increaseLoading()
      for childType in self.childTypes:
        xml_tree = currentTree.findall(childType)
        if xml_tree != None:
          for xml_data in xml_tree:
            child = self.add_childObj(childType, xml_data)
            child.load_child(xml_data)
      
  def save(self, parentTree, counter):
    counter.value += 1
    className = self.__class__.__name__
    if parentTree == None:
      xml_data = Element(className)
    else:
      xml_data = SubElement(parentTree, className)
    xml_data.set("id", str(self.getID()))
    xml_data.set("name", self.name)
    xml_data.set("pos", str(self.pos))
    for child in self.childObj:
      child.save(xml_data, counter)
    return xml_data
    
  def isTouched(self):
    return self.bTouched
 
  def add_childObj(self, childType, xml_data = None):
    if childType in self.childTypes:
      childClass = eval(childType)
      child = childClass()
      child.reset(self, xml_data)
      self.childObj.append(child)
      if gWorldEdit.getCurrentLevel() == self:
        child.draw()
      return child
  
  # clear    
  def clear(self):
    childObj = copy(self.childObj)
    for child in childObj:
      child.remove()
  
  def get_childObj(self):
    return self.childObj
    
  def pop_childObj(self, obj):
    if obj in self.childObj:
      # pop obj from childObj
      self.childObj.remove(obj)
    
  def draw_childObj(self):
    for child in self.childObj:
      child.draw()
  
  def exitLevel(self):
    for child in self.childObj:
      child.clearPopup()
 
  def touch_down(self, inst, touch):
    if self.collide_point(*touch.pos):
      self.bTouched = True
      self.do_translation = gWorldEdit.isEditMode and self.bMovable
      touch.grab(self)
      self.boxColor.a = 0.3
      gWorldEdit.selectObj(self)
      # check edit
      if gWorldEdit.isEditMode:
        self.bRedrawBridge = False
        # set delete callback
        if self.bDeletable:
          Clock.schedule_once(self.showPopup, 0.3)
        # double tap
        if touch.is_double_tap and self.childTypes:
          gWorldEdit.setCurrentLevel(self)
    # check popup widgets region and clear
    if touch.pos[0] < self.popupRect[0] or touch.pos[0] > self.popupRect[2] \
      or touch.pos[1] < self.popupRect[1] or touch.pos[1] > self.popupRect[3]:
        self.clearPopup()

  def touch_move(self, inst, touch):
    if self == touch.grab_current:
      if gWorldEdit.isEditMode:
        self.bRedrawBridge = True
      Clock.unschedule(self.showPopup)
      
  def touch_up(self, inst, touch):
    if self == touch.grab_current:
      self.bTouched = False
      touch.ungrab(self)
      self.boxColor.a = 0.0
      Clock.unschedule(self.showPopup)
      # edit mode
      if gWorldEdit.isEditMode:
        # redraw bridge
        if self.bRedrawBridge:
          self.bRedrawBridge = False
          if gBridge.hasBridge(self):
            gBridge.drawBridge()
      # enter the object
      elif self.childTypes:
        gWorldEdit.setCurrentLevel(self)
          
  def checkInRegion(self):
    x, y = self.pos
    if x < W * 0.2:
      x = W * 0.2
    elif x + self.size[0] > W * 0.8:
      x = W * 0.8 - self.size[0]
    if y < H * 0.2:
      y = H * 0.2
    elif y + self.size[1] > H * 0.8:
      y = H * 0.8 - self.size[1]
    self.pos = (x,y)
    
#---------------------#
# class : World
#---------------------#
class World(BaseObject, Singleton):
  childTypes = ["City"]
  name = "Kivy"
    
#---------------------#
# class : City
#---------------------#
class City(BaseObject):
  namelistFile = "city_names.txt"
  childTypes = ["Dungeon", "Town", "Gate", "Point"]
  icon = "city"
  bEnableBridge = True

#---------------------#
# class : Gate
#---------------------#
class Gate(BaseObject):
  icon = "building"
  name = "Gate"
  bEnableBridge = True
  bMovable = False
  bDeletable = False
  
#---------------------#
# class : Point
#---------------------#
class Point(BaseObject):
  icon = "point"
  name = ""
  bEnableBridge = True
  
#---------------------#
# class : Door
#---------------------#
class Door(BaseObject):
  icon = "point"
  name = "Door"
  bDeletable = False
  
#---------------------#
# class : Dungeon
#---------------------#
class Dungeon(BaseObject):
  namelistFile = "city_names.txt"
  childTypes = ["Monster", "Npc", "Gate", "Point"]
  icon = "dungeon"
  bEnableBridge = True
  
#---------------------#
# class : Town
#---------------------#
class Town(BaseObject):
  namelistFile = "city_names.txt"
  childTypes = ["Building", "Npc", "Monster", "Point", "Gate"]
  icon = "town"
  bEnableBridge = True
  
#---------------------#
# class : Building
#---------------------#
class Building(BaseObject):
  namelistFile = "building_names.txt"
  bUniqueName = False
  childTypes = ["Npc", "Monster", "Door"]
  icon = "building"
  bEnableBridge = True

#---------------------#
# class : Monster
#---------------------#
class Monster(BaseObject):
  namelistFile = "monster_names.txt"
  icon = "monster"
    
#---------------------#
# class : Npc
#---------------------#
class Npc(BaseObject):
  namelistFile = "npc_names.txt"
  icon = "npc"

#---------------------#
# class : Player
#---------------------#
class Player(BaseObject, Singleton):
  name = "Player"
  icon = "npc"
  bDeletable = False
  