from copy import copy
from xml.etree.ElementTree import Element, dump, parse, SubElement, ElementTree

import Utility as Util
from Utility import *
from ResourceMgr import gResMgr

from Globals import *

icon_size = WRect(0.1)

#---------------------#
# Global Instance
#---------------------#
def setGlobalInstance(WorldEdit, Bridge):
  global gWorldEdit
  global gBridge
  gWorldEdit = WorldEdit.instance()
  gBridge = Bridge.instance()
  
#---------------------#
# class : ObjectBase
#---------------------#
class BaseObject(Scatter):
  ID = -1
  namelistFile = ""
  namelist = []
  name = "No name"
  icon = ""
  label = None
  label_id = None
  bUniqueName = True
  parentObj = None
  childTypes = []
  childObj = []
  bTouched = False
  bRedrawBridge = False
  
  def __init__(self):
    # class method - load name library
    self.loadNamelist()

    # init scatter
    Scatter.__init__(self, size=icon_size)
    self.pos = cXY
    self.do_translation = False
    self.do_rotation = False
    self.do_scale = False
    self.auto_bring_to_front = False
    
    # set box region
    with self.canvas:
      self.boxColor = Color(0.7,0.7,1.0,0.0)
      Rectangle(size=self.size)
      Color(1,1,1)
      self.box = Rectangle(size=self.size)   
    
    # attach name label
    self.label = Label(text=self.name, center=mul(self.size, (0.5, 1.0)))
    self.label.pos[1] += self.label.size[1] * 0.1
    self.add_widget(self.label)
    
    # attach id label
    self.label_id = Label(text="-1", center=mul(self.size, (0.5, 1.0)))
    self.label_id.pos[1] = self.label.pos[1] + self.label.size[1] * 0.5
    
    # bind func
    self.bind(on_touch_down = self.touch_down,
      on_touch_move = self.touch_move,
      on_touch_up = self.touch_up)
    
  # reset data  
  def reset(self, parentObj, xml_data):
    if self == parentObj:
      return
    #init data
    self.parentObj = parentObj
    self.childObj = []
    self.bTouched = False
    self.bRedrawBridge = False
    
    # set icon
    if self.icon:
      self.box.texture = gResMgr.getTex(self.icon)
        
    # set loading data
    if xml_data == None:
      self.setNewName(self)
      self.setID(-1)
      self.pos = cXY
    else:
      self.setID(int(xml_data.get("id")))
      self.setName(xml_data.get("name"))
      self.pos = eval(xml_data.get("pos"))
    # regist object
    gWorldEdit.registObjID(self)
   
  def remove(self, *args):
    # recursive
    while self.childObj:
      self.childObj[0].remove()
    self.childObj = []
    
    # break link
    gBridge.breakLink(self)
    
    # pop my widget from parent 
    if self.parent:
      self.parent.remove_widget(self)
      
    # pop self from parent
    if self.parentObj:
      self.parentObj.pop_childObj(self)  
    self.parentObj = None
    
    # unregist
    gWorldEdit.unregistObjID(self)
    
  @classmethod
  def loadNamelist(cls):
    if cls.namelistFile and not cls.namelist:
      filepath = os.path.join("data", cls.namelistFile)
      if os.path.isfile(filepath):
        f = open(filepath, "r")
        cls.namelist = map(lambda x:x.strip(), list(f))
        f.close()    
  
  @classmethod
  def setNewName(cls, obj):
    if cls.namelist and len(cls.namelist) > 0:
      name = random.choice(cls.namelist).strip()
      obj.setName(name)
    else:
      # set default name
      obj.setName(cls.name)
  
  @classmethod
  def checkName(cls, objName):
    '''if is there name then remove..'''
    if cls.bUniqueName and objName in cls.namelist:
      cls.namelist.remove(objName)
      
  def setName(self, name):
    self.name = name
    self.label.text = name
    self.checkName(self.name)
    
  def getName(self):
    return self.name
  
  def getTitle(self):
    return self.__class__.__name__ + " - " + self.name
  
  def getID(self):
    return self.ID 
    
  def setID(self, ID):
    self.ID = ID
    self.label_id.text = "ID : " + str(self.ID)
    
  def draw(self):
    gWorldEdit.gameScreen.add_to_bg(self)
    # show id
    self.showID(gWorldEdit.isEditMode)
  
  def showID(self, bShow):
    if not self.label_id:
      return
    # toggle id label
    if bShow:
      if not self.label_id.parent:
        self.add_widget(self.label_id)
    elif self.label_id.parent:
      self.remove_widget(self.label_id)     
  
  def load(self, parentTree):
    xml_data = parentTree.find(self.__class__.__name__)\
      if parentTree != None else None
    # loading progress
    gMyRoot.increaseLoading()
    self.reset(None, xml_data)
    self.load_child(xml_data)
      
  def load_child(self, currentTree):
    # load child data
    if currentTree != None:   
      # loading progress
      gMyRoot.increaseLoading()
      for childType in self.childTypes:
        xml_tree = currentTree.findall(childType)
        if xml_tree != None:
          for xml_data in xml_tree:
            child = self.add_childObj(childType, xml_data)
            child.load_child(xml_data)
      
  def save(self, parentTree, counter):
    counter.value += 1
    className = self.__class__.__name__
    if parentTree == None:
      xml_data = Element(className)
    else:
      xml_data = SubElement(parentTree, className)
    xml_data.set("id", str(self.getID()))
    xml_data.set("name", self.name)
    xml_data.set("pos", str(self.pos))
    for child in self.childObj:
      child.save(xml_data, counter)
    return xml_data
    
  def isTouched(self):
    return self.bTouched
 
  def add_childObj(self, childType, xml_data = None):
    if childType in self.childTypes:
      childClass = eval(childType)
      child = childClass()
      child.reset(self, xml_data)
      self.childObj.append(child)
      if gWorldEdit.getCurrentLevel() == self:
        child.draw()
      return child
  
  # clear    
  def clear(self, *args):
    while self.childObj:
      self.childObj[0].remove()
  
  def get_childObj(self):
    return self.childObj
    
  def pop_childObj(self, obj):
    if obj in self.childObj:
      # pop obj from childObj
      self.childObj.remove(obj)
    
  def draw_childObj(self):
    for child in self.childObj:
      child.draw()
 
  def touch_down(self, inst, touch):  
    if self.collide_point(*touch.pos):
      self.bTouched = True
      self.do_translation = gWorldEdit.isEditMode
      touch.grab(self)
      self.boxColor.a = 0.3
      gWorldEdit.selectObj(self)
      # check edit
      if gWorldEdit.isEditMode:
        self.bRedrawBridge = False
        Clock.schedule_once(gWorldEdit.remove_selected, 1.0)
        # double tap
        if touch.is_double_tap:
          gWorldEdit.setCurrentLevel(self)
      else:
        gWorldEdit.setCurrentLevel(self)
    
  def touch_move(self, inst, touch):
    if self == touch.grab_current:
      if gWorldEdit.isEditMode:
        self.bRedrawBridge = True
      Clock.unschedule(gWorldEdit.remove_selected)
      
  def touch_up(self, inst, touch):
    if self == touch.grab_current:
      self.bTouched = False
      touch.ungrab(self)
      self.boxColor.a = 0.0
      Clock.unschedule(gWorldEdit.remove_selected)
      # redraw bridge
      if gWorldEdit.isEditMode and self.bRedrawBridge:
        self.bRedrawBridge = False
        if gBridge.hasBridge(self):
          gBridge.drawBridge()
    
#---------------------#
# class : World
#---------------------#
class World(BaseObject, Singleton):
  childTypes = ["City"]
  name = "Kivy"
    
#---------------------#
# class : City
#---------------------#
class City(BaseObject):
  namelistFile = "city_names.txt"
  childTypes = ["Dungeon", "Town"]
  icon = "city"
  
#---------------------#
# class : Dungeon
#---------------------#
class Dungeon(BaseObject):
  namelistFile = "city_names.txt"
  childTypes = ["Monster"]
  icon = "dungeon"
  
#---------------------#
# class : Town
#---------------------#
class Town(BaseObject):
  namelistFile = "city_names.txt"
  childTypes = ["Building", "Npc"]
  icon = "town"
  
#---------------------#
# class : Building
#---------------------#
class Building(BaseObject):
  namelistFile = "building_names.txt"
  bUniqueName = False
  childTypes = ["Npc"]
  icon = "building"

#---------------------#
# class : Monster
#---------------------#
class Monster(BaseObject):
  namelistFile = "monster_names.txt"
  icon = "monster"
    
#---------------------#
# class : Npc
#---------------------#
class Npc(BaseObject):
  namelistFile = "npc_names.txt"
  icon = "npc"

#---------------------#
# class : Player
#---------------------#
class Player(BaseObject, Singleton):
  name = "Player"
  icon = "npc"