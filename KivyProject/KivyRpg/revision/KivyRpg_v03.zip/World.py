import Utility as Util
from Utility import *
from Character import *
from ResourceMgr import gResMgr

from xml.etree.ElementTree import Element, dump, parse, SubElement, ElementTree

icon_size = WRect(0.1)

#---------------------#
# Global Instance
#---------------------#
def setGlobalInstance():
  global gWorldEdit, gWorld
  gWorldEdit = WorldEdit.instance()
  gWorld = World.instance()

#---------------------#
# class : WorldEdit
#---------------------#    
class WorldEdit(Singleton):
  city = []
  gameScreen = None
  currentLevel = None
  selectedObj = None
  isEditMode = False
  widgets = Widget()
  widgets.name = "WorldEditUI"
  onExitFunc = None
  
  def bind_OnExit(self, func):
    self.onExitFunc = func
  
  def build_ui(self):
      # level name
      if not hasattr(self, "currentLevelName"):
        self.currentLevelName = Label(text="World", font_size="30dp", pos=(0,H-100), size=(W,100))
      if not self.currentLevelName.parent:
        self.gameScreen.add_to_ui(self.currentLevelName)
      self.currentLevelName.text = self.currentLevel.__class__.__name__ + \
        " - " + self.currentLevel.name
        
      btn_size = (300, 70)
      btn_pos = sub(WH, btn_size)
      if not hasattr(self, "btn_edit"):
        self.btn_edit = Button(text="Edit Mode", pos=btn_pos, size=btn_size)
        self.btn_edit.bind(on_release = lambda x:self.setEditMode(not self.isEditMode))
      if not self.btn_edit.parent:
        self.gameScreen.add_to_ui(self.btn_edit)
      btn_pos[1] -= btn_size[1]
      
      self.widgets.clear_widgets()
      def add_button(text, func, userData = None):
        btn = Button(text=text, pos=btn_pos, size=btn_size)
        btn.userData = userData
        btn.bind(on_release = func)
        btn_pos[1] -= btn_size[1]
        self.widgets.add_widget(btn)
      add_button("Exit", self.exit)
      add_button("Clear", self.clearCurrentLevel)
      add_button("Remove", lambda x:self.remove_selected())
      for childType in self.currentLevel.childTypes:
        add_button("Add " + childType, self.add_object, childType)
      
      self.selectObjName = TextInput(text = "", multiline=False, size=btn_size, pos=btn_pos,
        background_color=(1,1,1,0.1), foreground_color=(1,1,1,1))
      self.selectObjName.bind(on_text_validate = self.setSelectedObjName)
      # widgets
      self.widgets.add_widget(self.selectObjName)
  
  def exit(self, *args):
    if self.onExitFunc:
      self.onExitFunc()   
    self.selectObj(None)
    gWorld.clear()
   
  def onTouchPrev(self, *args):
    if self.getParentLevel():
      self.gotoParentLevel()
      return True
    # exit
    return False
    
  def setEditMode(self, bEdit):
    self.isEditMode = bEdit
    if self.isEditMode and not self.widgets.parent:
      self.gameScreen.add_to_ui(self.widgets)
    elif self.widgets.parent:
      self.widgets.parent.remove_widget(self.widgets)
      
  def setSelectedObjName(self, inst):
    if self.selectedObj:
      self.selectedObj.setName(inst.text)
      
  def selectObj(self, obj):
    self.selectedObj = obj
    self.selectObjName.text = obj.getName() if obj else ""
  
  def getSelected(self):
    return self.selectedObj
    
  def isSelected(self, obj):
    return self.selectedObj is obj
    
  def add_object(self, inst):
    self.currentLevel.add_childObj(inst.userData, None)
  
  def remove_selected(self, *args):
    if self.selectedObj:
      self.selectedObj.remove()
    self.selectObj(None)
    
  def clearCurrentLevel(self, *args):
    if self.currentLevel:
      self.currentLevel.clear()
        
  def getCurrentLevel(self):
    return self.currentLevel
    
  def setCurrentLevel(self, currentLevel):
    self.gameScreen.clear_bg()
    self.currentLevel = currentLevel
    self.build_ui()
    self.currentLevel.draw_childObj()
    self.selectObj(None)
      
  def getParentLevel(self):
    return self.currentLevel.parentObj
  
  def gotoParentLevel(self):
    parentObj = self.getParentLevel()
    if parentObj:
      self.setCurrentLevel(parentObj)

  def load(self, filename, screen):
    self.gameScreen = screen
       
    # set current level
    gWorld.clear()
    self.setCurrentLevel(gWorld)
    self.setEditMode(True)
    
    # load save data
    self.filename = filename
    try:
      tree = parse(filename)
      root = tree.getroot()
      gWorld.load(root)
    except:
      pass
    
  def save(self, filename):
    root = gWorld.save()
    ElementTree(root).write(filename)

#---------------------#
# class : ObjectBase
#---------------------#
class BaseObject(Scatter):
  namelistFile = ""
  namelist = []
  name = "No name"
  icon = "star"
  bUniqueName = True
  parentObj = None
  childTypes = []
  childObj = []
  
  def __init__(self, parentObj, xml_data = None):
    self.name = "No name"
    self.parentObj = parentObj   
    self.childObj = []
    
    self.loadNamelist()
    
    Scatter.__init__(self, size=icon_size)
    self.pos = cXY
    self.do_translation = False
    self.do_rotation = False
    self.do_scale = False
    with self.canvas:
      self.boxColor = Color(0.7,0.7,1.0,0.0)
      Rectangle(size=self.size)
      Color(1,1,1)
      Rectangle(texture=gResMgr.getTex(self.icon), size=self.size)
    self.label = Label(text=self.name, center=mul(self.size, (0.5, 1.0)))
    self.label.pos[1] += self.label.size[1] * 0.1
    self.add_widget(self.label)
    self.villages = {}
    
    self.bind(on_touch_down = self.touch_down,
      on_touch_move = self.touch_move,
      on_touch_up = self.touch_up)
    
    # set name
    if xml_data == None:
      self.setNewName(self)
    else:
      self.setName(xml_data.get("name"))
      self.pos = eval(xml_data.get("pos"))
      
  @classmethod
  def loadNamelist(cls):
    if cls.namelistFile and not cls.namelist:
      filepath = os.path.join("data", cls.namelistFile)
      if os.path.isfile(filepath):
        f = open(filepath, "r")
        cls.namelist = map(lambda x:x.strip(), list(f))
        f.close()    
  
  @classmethod
  def setNewName(cls, obj):
    if cls.namelist and len(cls.namelist) > 0:
      name = random.choice(cls.namelist).strip()
      obj.setName(name)
  
  @classmethod
  def checkName(cls, objName):
    '''if is there name then remove..'''
    if cls.bUniqueName and objName in cls.namelist:
      cls.namelist.remove(objName)
      
  def setName(self, name):
    self.name = name
    self.label.text = name
    self.checkName(self.name)
    
  def getName(self):
    return self.name  
    
  def load(self, currentTree):
    for childType in self.childTypes:
      xml_tree = currentTree.findall(childType)
      for xml_data in xml_tree:
        child = self.add_childObj(childType, xml_data)
        child.load(xml_data)
    
  def save(self, parentTree = None):
    className = self.__class__.__name__
    xml_data = Element(className) if parentTree == None\
      else SubElement(parentTree, className)
    xml_data.set("name", self.name)
    xml_data.set("pos", str(self.pos))
    for child in self.childObj:
      child.save(xml_data)
    return xml_data
 
  def add_childObj(self, childType, xml_data):
    if childType in self.childTypes:
      childClass = eval(childType)
      child = childClass(self, xml_data)
      self.childObj.append(child)
      if gWorldEdit.getCurrentLevel() == self:
        gWorldEdit.gameScreen.add_to_bg(child)
      return child
  
  def remove(self, *args):   
    while self.childObj:
      self.childObj[0].remove()
    
    if self.parent:
      self.parent.remove_widget(self)
    
    if self.parentObj:
      self.parentObj.pop_childObj(self)
      
  def clear(self, *args):
    while self.childObj:
      self.childObj[0].remove()
    
  def pop_childObj(self, obj):
    if obj in self.childObj:
      self.childObj.remove(obj)  
        
  def draw_childObj(self):
    for child in self.childObj:
      gWorldEdit.gameScreen.add_to_bg(child)
    
  def touch_down(self, inst, touch):  
    if self.collide_point(*touch.pos):
      self.do_translation = gWorldEdit.isEditMode
      touch.grab(self)
      self.boxColor.a = 0.3
      gWorldEdit.selectObj(self)
      if gWorldEdit.isEditMode:
        Clock.schedule_once(gWorldEdit.remove_selected, 1.0)
        # double tap
        if touch.is_double_tap:
          gWorldEdit.setCurrentLevel(self)
      else:
        gWorldEdit.setCurrentLevel(self)
    
  def touch_move(self, inst, touch):
    if self == touch.grab_current:
      Clock.unschedule(gWorldEdit.remove_selected)
    
  def touch_up(self, inst, touch):
    if self == touch.grab_current:
      touch.ungrab(self)
      self.boxColor.a = 0.0
      Clock.unschedule(gWorldEdit.remove_selected)

#---------------------#
# class : World
#---------------------#
class World(BaseObject, Singleton):
  childTypes = ["City"]
  name = "Kivy"
  
  def __init__(self):
    pass
    
#---------------------#
# class : City
#---------------------#
class City(BaseObject):
  namelistFile = "city_names.txt"
  childTypes = ["Dungeon", "Town"]
  icon = "city"
  
#---------------------#
# class : Dungeon
#---------------------#
class Dungeon(BaseObject):
  namelistFile = "city_names.txt"
  childTypes = ["Monster"]
  icon = "dungeon"
  
#---------------------#
# class : Town
#---------------------#
class Town(BaseObject):
  namelistFile = "city_names.txt"
  childTypes = ["Building", "Npc"]
  icon = "town"
  
#---------------------#
# class : Building
#---------------------#
class Building(BaseObject):
  namelistFile = "building_names.txt"
  bUniqueName = False
  childTypes = ["Npc"]
  icon = "building"

#---------------------#
# class : Monster
#---------------------#
class Monster(BaseObject):
  namelistFile = "monster_names.txt"
  icon = "monster"
    
#---------------------#
# class : Npc
#---------------------#
class Npc(BaseObject):
  namelistFile = "npc_names.txt"
  icon = "npc"
    
#---------------------#
# set global instance
#---------------------#
setGlobalInstance()