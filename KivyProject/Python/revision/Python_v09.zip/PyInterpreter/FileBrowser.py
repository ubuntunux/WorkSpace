import Utility as Util
from Utility import *

from Constants import *

global gFileBrowser

#---------------------#
# CLASS : TouchableLabel
#---------------------#  
class TouchableLabel(Label):
  isDirType = False
  def on_touch_down(self, touch):
    if self.collide_point(*touch.pos):
      selectfile = os.path.join(gFileBrowser.dirname, self.text[2:] if self.isDirType else self.text)
      if os.path.isdir(selectfile):
        gFileBrowser.open_directory(selectfile)
      elif os.path.isfile(selectfile):
        gFileBrowser.open_file(selectfile)
        
  def setType(self, isDir):
    self.isDirType = isDir
    if isDir:
      self.color = [1,1,0.5,2]
      self.text = "> " + self.text
    else:
      self.color = [1,1,1,1]
       
#---------------------#
# CLASS : FileBrowser
#---------------------#    
class FileBrowser(Singleton):
  def __init__(self, ui):
    global gFileBrowser
    gFileBrowser = self
    self.ui = ui
    self.lastDir = ""
    # filename input layout
    self.filenameLayout = BoxLayout(orientation = "horizontal", size_hint=(1, None))
    self.filenameInput = TextInput(text="input filename", multiline = False, padding_y="15dp", font_name=defaultFont, size_hint=(1,None))
    self.filenameInput.height = self.filenameInput.minimum_height
    self.filenameLayout.height = self.filenameInput.height
    self.filenameInput.bind(focus=self.inputBoxFocus)
    btn_save = Button(text="Save", size_hint=(0.2,1), background_color=[1,1,1,2])
    btn_save.bind(on_release = self.save_as)
    self.filenameLayout.add_widget(self.filenameInput)
    self.filenameLayout.add_widget(btn_save)
    
    # file browser
    self.fileLayout = BoxLayout(orientation="vertical", size_hint=(1,None))
    self.fileSV = ScrollView(size_hint=(1,1))
    self.fileSV.add_widget(self.fileLayout)
    
    # current directory
    self.curDir = Label(text="", text_size=(W * 0.9, None), size_hint_y=None, height=kivy.metrics.dp(50))
    
    #  rowser layout
    self.browserLayout = BoxLayout(orientation="vertical", pos_hint={"top":1}, size_hint=(1,1))
    self.browserLayout.add_widget(self.curDir)
    self.browserLayout.add_widget(self.fileSV)
    self.browserLayout.add_widget(self.filenameLayout)
    self.popup = Popup(title = "File Browser", content=self.browserLayout, auto_dismiss=False, size_hint=(1, 0.8)) 
  
  def open_file(self, filename):
    self.ui.editorLayout.open_file(filename)
    self.close()
    
  def open_directory(self, dirname):
    self.dirname = os.path.abspath(dirname)
    self.curDir.text = self.dirname
    self.fileLayout.clear_widgets()
    dirname, dirList, fileList = os.walk(self.dirname).next()
    fileList = sorted(fileList, key=lambda x:x.lower())
    dirList = sorted(dirList, key=lambda x:x.lower())
    fileList = dirList + fileList
    fileList.insert(0, "..")
    labelHeight = kivy.metrics.dp(25)
    for filename in fileList:
      absFilename = os.path.join(dirname, filename)
      label = TouchableLabel(text=filename, font_size="15dp", size_hint_y = None, size=(W*0.9, labelHeight), shorten=True, shorten_from="right", halign="left")
      label.text_size = label.size
      label.setType(os.path.isdir(absFilename))
      self.fileLayout.add_widget(label)
    self.fileLayout.height = labelHeight * len(self.fileLayout.children)
  
  def save_as(self, inst):
    if self.filenameInput.text:
      filename = os.path.join(gFileBrowser.dirname, self.filenameInput.text)
      self.ui.editorLayout.save_as(self.filenameInput.text)
    self.close()
    
  def showOpenLayout(self):
    if self.filenameLayout.parent:
      self.browserLayout.remove_widget(self.filenameLayout)
    self.filenameInput.text = ""
    self.popup.open()
    self.open_directory(".")
  
  def showSaveAsLayout(self):
    if not self.filenameLayout.parent:
      self.browserLayout.add_widget(self.filenameLayout)
    self.filenameInput.text = ""
    self.popup.open()
    self.open_directory(".")
     
  def close(self):
    self.inputBoxForceFocus(False)
    self.popup.dismiss()
    self.ui.setMode(szEditor)
     
  def touchPrev(self):
    if self.filenameInput.focus:
      self.inputBoxForceFocus(False)
    else:
      self.close()
    
  def inputBoxForceFocus(self, bFocus):
    if self.filenameInput and bFocus != self.filenameInput.focus:
      self.reFocusInputText = False
      self.filenameInput.focus = bFocus 
      
  def inputBoxFocus(self, inst, bFocus):
    bAlwaysPreserveFocus = True
    if not bFocus:
      if self.reFocusInputText:
        self.reFocusInputText = bAlwaysPreserveFocus
        inst.focus = True
    self.reFocusInputText = bAlwaysPreserveFocus
    self.refreshLayout()
    
  def refreshLayout(self):
    if self.browserLayout.size_hint_y != None:
      self.browserLayout.size_hint_y = None
      self.browserLayout_height = self.browserLayout.height
    
    if self.filenameInput.focus: 
      offset = gMyRoot.getKeyboardHeight() - self.browserLayout.pos[1]
      self.browserLayout.height = self.browserLayout_height - offset
    else:
      self.browserLayout.height = self.browserLayout_height
    