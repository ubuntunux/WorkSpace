import Utility as Util
from Utility import *

from kivy import metrics
from kivy.animation import Animation

from glob import glob

#---------------------#
# CLASS : REPL
#---------------------#
class REPL(Singleton):
  name = "Python REPL"
  result = ""
  code = []
  lastCode = ""
  myGlobals = {}
  isIndentMode = False
  ui = None
  
  def __init__(self, ui):
    self.ui = ui
       
  def onConsoleInput(self, inputText):
    result = self.run_script(inputText)
    
    # insert result
    if result:
      self.ui.displayText(result)
    
    if self.lastCode:
      temp = self.lastCode
      self.lastCode = None
      self.onConsoleInput(temp)
      
  def run_script(self, code):
    # run script
    stripCode = code.strip()
    if self.code and (stripCode == "" or code[0] != " " and code[0] != "\t"):
      self.lastCode = code
      code = "\n".join(self.code)
      self.isIndentMode = False
      self.code = []
      
    # inner indent mode
    elif self.code or stripCode and stripCode[-1] == ":":
      self.code.append(code)
      self.isIndentMode = True
      return None
      
    try:
      self.old_stdout = sys.stdout
      self.redirected_output = sys.stdout = StringIO()
      try:
        print eval(code, self.myGlobals)
      except:
        exec(code, self.myGlobals)
        
      sys.stdout = self.old_stdout
      self.result = self.redirected_output.getvalue()
    except Exception, e:
      self.errorstring = traceback.format_exc()
      self.result = ("ERROR: " + self.errorstring)
    return self.result[:-1]

#---------------------#
# CLASS : Tutorial layout class
#---------------------#    
class TutorialLayout(BoxLayout):
  def __init__(self, ui):
    BoxLayout.__init__(self, orientation="vertical", size_hint_y=None)
    #with self.canvas:
    #  Color(0.3,0.3,0.5)
    #  Rectangle(size=WH)
    self.ui = ui
    self.tutorialMap = {}
    layout_height = 0
    
    # add title header
    image = Image(source="python_logo.png", allow_stretch=True, keep_ratio=True, size_hint_x=None)
    label_Title = Label(text = "Python Tutorials", font_size="30dp", bold=True, color=[1.0,0.7,0.4,1])
    layout = BoxLayout(orientation="horizontal", padding=[metrics.dp(20),0,0,0], size_hint=(1, 50.0/30.0)) 
    layout.add_widget(image)
    layout.add_widget(label_Title)
    self.add_widget(layout)
    layout_height += metrics.dp(50)
    
    # create tutorial buttons  
    for dirpath, dirnames, filenames in os.walk("tutorials"):
      # add category label
      if filenames:
        label_category = Label(text = os.path.split(dirpath)[-1], font_size="18dp", halign="left", bold=True, color=[1.0,0.85,0.7,1], size_hint_y=40.0/30.0)
        self.add_widget(label_category)
        layout_height += metrics.dp(40)
      # add tutorials
      for filename in filenames:
        # load tutorial file
        f = open(os.path.join(dirpath, filename), "r")
        lines = list(f)
        f.close()
        
        # split to description and code
        lines = "".join(lines).split("\n----\n")
        
        desc = lines[0]
        code = lines[1] if len(lines) > 1 else ""
        
        # add a button
        btn = Button(text=desc[:desc.find("\n")], font_size="15dp", size_hint_y=1)
        btn.bind(on_release = self.chooseTutorial)
        self.tutorialMap[btn] = (desc, code)
        self.add_widget(btn)
        layout_height += metrics.dp(30)
    # refresh height
    self.height = layout_height
  
  def chooseTutorial(self, btn):
    if btn in self.tutorialMap:
      desc, code = self.tutorialMap[btn]
      self.ui.displayText("\n-------------------------")
      self.ui.displayText("Tutorial : " + desc)
      self.ui.displayText("------------------------\n\nLet's try this!!\n")
      self.ui.textInput.text = code
      self.ui.runCode(None)
      self.ui.setInputText(code)
      self.ui.showWidget(self, False)

#---------------------#
# CLASS : Editor
#---------------------#
class Editor(Screen):
  def __init__(self):
    Screen.__init__(self, name="Python Editor")

#---------------------#
# CLASS : PyInterpreter
#---------------------#    
class PyInterpreter(Singleton):
  isInit = False
  bExitOnTouchPrev = True
  
  def init(self):
    if self.isInit:
      return
      
    self.screen = Screen(name="Python Interpreter")
    self.editorScreen = Editor()
    self.repl = REPL(self)
    self.history = ["",]
    self.historyIndex = -1
    self.historyCount = 100
    self.lastIndentSpace = ""
    self.defaultFont = kivy.resources.resource_find(os.path.join("fonts","DroidSansMonoDotted.ttf"))
    self.bIndentMode = False
    self.reFocusInputText = False
    self.oldTouchPrev = None
    self.textInputWidth = W * (4.0/5.0)
    
    # tutorial
    self.tutorialLayout = TutorialLayout(self)
    
    # layout
    self.layout = GridLayout(cols=6, size_hint=(1, None), height="35dp")
    self.screen.add_widget(self.layout)
    
    # buttons
    btn_tutorial = Button(text="Tutorial", size_hint=(1.0, 1.0), background_color=[1.5,1.5,0.7,1])
    btn_tutorial.bind(on_release = lambda inst:self.toggleWidget( self.tutorialLayout ))
    btn_editor = Button(text="Editor", size_hint=(1.0, 1.0), background_color=[1.5,1.5,0.7,1])
    btn_editor.bind(on_release = lambda inst:self.toggleWidget( self.tutorialLayout ))
    btn_prev = Button(text="<<")
    btn_next = Button(text=">>")
    btn_clear = Button(text="Clear")
    btn_exit = Button(text="Exit", background_color=[1,0.7,0.7,1])
    btn_exit.bind(on_release = self.exit)
    self.layout.add_widget(btn_tutorial)
    self.layout.add_widget(btn_prev)
    self.layout.add_widget(btn_next)
    self.layout.add_widget(btn_clear)
    self.layout.add_widget(btn_exit)
    
    # text input
    self.textInput = TextInput(text = "text", multiline=True, size_hint=(None, None), font_name=self.defaultFont, auto_indent = True,
      background_color=(1,1,1,0.2), foreground_color=(1,1,1,1), text_size=(0,0), font_size="14dp", padding_x="20dp", padding_y="15dp")  
    self.textInput.size = (self.textInputWidth, self.textInput.minimum_height)
    self.textInput.text = ""
    # method for singleline
    #self.textInput.bind(on_text_validate = self.onConsoleInput)
    self.textInput.bind(focus = self.inputBoxFocus)
    def refreshTextInputSize(*args):
      if self.textInput.size[1] != self.textInput.minimum_height:
        self.textInput.size = (self.textInput.size[0], self.textInput.minimum_height)
        self.refreshLayout(gMyRoot.getKeyboardHeight() if self.textInput.focus else 0)
    # method for multiline
    self.textInput.bind(text = refreshTextInputSize)
    # bind paste
    def paste():
      self.insertInputText(gMyRoot.getClipboard())
    self.textInput.paste = paste
    self.textInput.copy(data=" ")
    # add input widget
    self.screen.add_widget(self.textInput)
    
    # run button
    self.btn_run = Button(text="Run", size_hint=(None,None), size =(W-self.textInput.size[0], self.textInput.size[1]),\
      background_color=(1,1,2,1))
    self.btn_run.bind(on_release = self.runCode)
    self.btn_run.pos = (W - self.btn_run.size[0], 0)
    self.screen.add_widget(self.btn_run)
    
    # output
    self.outputSV = ScrollView(size_hint=(None, None))
    self.screen.add_widget(self.outputSV)
    
    self.outputLayout = BoxLayout(orientation="vertical", size_hint_y=None)
    
    # buttons bind
    def func_clear(inst):
      self.outputLayout.clear_widgets()
      self.outputLayout.size = (W, 0)
    btn_clear.bind(on_release = func_clear)
    
    def func_prev(inst):         
      if len(self.history) > 0:
        self.historyIndex -= 1
        if self.historyIndex < 0:
          self.historyIndex = len(self.history) - 1
        text = self.history[self.historyIndex]
        if text.find("\n") > -1:
          self.bIndentMode = True
        self.setInputText(text)
    btn_prev.bind(on_release = func_prev)
    
    def func_next(inst):
      if len(self.history) > 0:
        self.historyIndex += 1
        if self.historyIndex >= len(self.history):
          self.historyIndex = 0
        text = self.history[self.historyIndex]
        if text.find("\n") > -1:
          self.bIndentMode = True
        self.setInputText(text)
    btn_next.bind(on_release = func_next) 
    
    # editor
    self.editor = TextInput(text = "text", multiline=True, size_hint=(1, None), font_name=self.defaultFont, auto_indent = True,
      background_color=(1,1,1,0.2), foreground_color=(1,1,1,1), text_size=(0,0), font_size="14dp", padding_x="20dp", padding_y="15dp")  
    self.editor.size = (self.editor.size[0], self.editor.minimum_height)
    self.editor.text = ""
    def refreshEditorSize(*args):
      if self.editor.size[1] != self.editor.minimum_height:
        self.editor.size = (self.editor.size[0], self.editor.minimum_height)
    self.editor.bind(text = refreshEditorSize)
    def paste():
      self.editor.insert_text(gMyRoot.getClipboard())
      refreshEditorSize()
    self.editor.paste = paste
    
    # show output layout
    self.showWidget(self.tutorialLayout, False)
    self.displayText("Python " + sys.version)
    self.refreshLayout()
    self.isInit = True
    
  def toggleWidget(self, widget):
    self.showWidget(widget, widget.parent == None)
    
  def showWidget(self, widget, bShow):
    if bShow:
      widget.opacity = 0
      Animation(opacity=1.0, duration=0.2).start(widget)
      if self.outputLayout.parent:
        self.outputLayout.parent.remove_widget(self.outputLayout)
      if not widget.parent:
        self.outputSV.add_widget(widget)
    else:
      self.outputLayout.opacity = 0
      Animation(opacity=1.0, duration=0.2).start(self.outputLayout)
      if widget.parent:
        widget.parent.remove_widget(widget)
      if not self.outputLayout.parent:
        self.outputSV.add_widget(self.outputLayout)
    
  def setExitOnTouchPrev(self, bValue):
    self.bExitOnTouchPrev = bValue
  
  def start(self):
    self.show()
    
  def update(self, dt):
    pass
      
  def displayText(self, text, background_color=(1,1,1,0)):
    if type(text) != str:
      text = str(text)
       
    output = TextInput(markup = True, text="", halign='left', valign='top', readonly=True, font_size="12dp", font_name = self.defaultFont,
      multiline=True, background_color=background_color, foreground_color=(1,1,1,1), size_hint_y=None, size = (W, 0))
    output.text = text
    output.size = (W, output.minimum_height)
    
    self.outputLayout.add_widget(output)
    self.outputLayout.size = (W, self.outputLayout.size[1] + output.size[1])
    self.outputSV.scroll_y = 0 
  
  def runCode(self, inst):
    self.onConsoleInput(self.textInput, True)
    
  def onConsoleInput(self, inst, bForceRun = False):
    self.reFocusInputText = True
    if inst.text.strip():
      bRunCode = len(inst.text) == self.textInput.cursor_index()
      lastLine_nonStrip = inst.text.split("\n")[-1]
      lastLine = lastLine_nonStrip.strip()
      # indent mode - continue input but not run
      #if not bForceRun and lastLine and (lastLine[-1] in ("\\", ":") or self.bIndentMode or not bRunCode):
      if not bForceRun: # run with button
        self.bIndentMode = True
        # get indent space
        self.lastIndentSpace = ""
        if self.bIndentMode:
          for i in lastLine_nonStrip:
            if i in [" ", "\t"]:
              self.lastIndentSpace += i
            else:
              break
        inst.insert_text("\n" + self.lastIndentSpace)
        self.textInput.size = (W, self.textInput.minimum_height)
        return
      # check indent mode - run code
      self.bIndentMode = False
      # pop input text from history
      if len(self.history) > 0 and self.historyIndex > -1 \
        and self.historyIndex < len(self.history) and self.history[self.historyIndex] == inst.text:
          self.history.pop(self.historyIndex)
      # append item to history
      self.history.append(inst.text.strip())
      # check history count
      if len(self.history) > self.historyCount:
        self.history = self.history[:self.historyCount]
      self.historyIndex = len(self.history)
      # display input text to output widget
      lines = inst.text.split("\n")
      result = []
      for i, line in enumerate(lines):
        line = (">> " if i == 0 else ".. ") + line
        result.append(line)
      result = "\n".join(result)
      self.displayText(result)
      # run code
      self.repl.onConsoleInput(inst.text)
      self.setInputText("")
      
  def refreshLayout(self, offset = 0):
    topMargin = kivy.metrics.dp(30)
    self.textInput.pos = (0, offset)
    self.btn_run.pos = (self.btn_run.pos[0], offset)
    limitHeight = (H - offset - topMargin) * 0.5
    if self.textInput.minimum_height > limitHeight:
      height = limitHeight
    else:
      height = self.textInput.minimum_height
    self.textInput.size = (self.textInputWidth, height)
    self.btn_run.size = (W - self.textInputWidth, height)
    self.layout.pos = (0, self.textInput.size[1] + offset) 
    self.outputSV.pos = (0, self.textInput.size[1] + self.layout.size[1] + offset)
    self.outputSV.size = (W, H - (topMargin + self.textInput.size[1] + self.layout.size[1] + offset))
  
  def setInputText(self, text):
    self.textInput.text = text
    if self.textInput.size[1] != self.textInput.minimum_height:
      self.refreshLayout(gMyRoot.getKeyboardHeight() if self.textInput.focus else 0)
  
  def insertInputText(self, text):
    self.textInput.insert_text(text)
    if self.textInput.size[1] != self.textInput.minimum_height:
      self.refreshLayout(gMyRoot.getKeyboardHeight() if self.textInput.focus else 0)
  
  def inputBoxForceFocus(self, bFocus):
    if bFocus != self.textInput.focus:
      self.textInput.focus = bFocus 
      
  def inputBoxFocus(self, inst, bFocus):
    bAlwaysPreserveFocus = False
    if bFocus:
      self.refreshLayout(gMyRoot.getKeyboardHeight())
    else:
      self.refreshLayout()
      if self.reFocusInputText:
        self.reFocusInputText = bAlwaysPreserveFocus
        self.textInput.focus = True
    self.reFocusInputText = bAlwaysPreserveFocus
    
  def update(self, dt):
    pass
    
  def touchPrev(self):
    if not self.outputLayout.parent:
      self.showWidget(self.tutorialLayout, False)
    else:
      if self.textInput.focus:
        self.reFocusInputText = False
        self.inputBoxForceFocus(False)
      else:
        self.exit()
      
  def toggle(self):
    if not self.isInit:
      self.init()
      
    if self.screen.name == gMyRoot.myScreen.get_current_screen():
      self.close()
    else:
      self.show()
      
  def show(self):
    if not self.isInit:
      self.init()
      
    gMyRoot.add_screen(self.screen)
    gMyRoot.current_screen(self.screen)
    self.oldTouchPrev = gMyRoot.getTouchPrev()
    gMyRoot.setTouchPrev(self.touchPrev)
  
  def close(self):
    gMyRoot.setTouchPrev(self.oldTouchPrev)
    gMyRoot.remove(self)
    gMyRoot.remove_screen(self.screen)
    if self.bExitOnTouchPrev:
      gMyRoot.exit()
        
  def exit(self, *args):
    self.reFocusInputText = False
    self.inputBoxForceFocus(False)
    gMyRoot.popup("Exit Python?", self.close, None)