import Utility as Util
from Utility import *

from ResourceMgr import ResourceMgr
resMgr = ResourceMgr.instance()

#---------------------#
# CLASS : REPL
#---------------------#
class REPL(Singleton):
  name = "Python REPL"
  result = ""
  code = []
  lastCode = ""
  myGlobals = {}
  isIndentMode = False
  ui = None
  
  def __init__(self, ui):
    self.ui = ui
       
  def onConsoleInput(self, inputText):
    result = self.run_script(inputText)
    
    # insert result
    if result:
      self.ui.displayText(result)
    
    if self.lastCode:
      temp = self.lastCode
      self.lastCode = None
      self.onConsoleInput(temp)
      
  def run_script(self, code):
    # run script
    stripCode = code.strip()
    if self.code and (stripCode == "" or code[0] != " " and code[0] != "\t"):
      self.lastCode = code
      code = "\n".join(self.code)
      self.isIndentMode = False
      self.code = []
      
    # inner indent mode
    elif self.code or stripCode and stripCode[-1] == ":":
      self.code.append(code)
      self.isIndentMode = True
      return None
      
    try:
      self.old_stdout = sys.stdout
      self.redirected_output = sys.stdout = StringIO()
      try:
        print eval(code, self.myGlobals)
      except:
        exec(code, self.myGlobals)
        
      sys.stdout = self.old_stdout
      self.result = self.redirected_output.getvalue()
    except Exception, e:
      self.errorstring = traceback.format_exc()
      self.result = ("ERROR: " + self.errorstring)
    return self.result[:-1]

#---------------------#
# CLASS : PyInterpreter
#---------------------#    
class PyInterpreter(Singleton):
  def __init__(self):
    self.screen = Screen(name="MainScreen")
    self.repl = REPL(self)
    self.lastAction = "None"
    self.history = ["",]
    self.historyIndex = -1
    self.historyCount = 100
    self.lastIndentSpace = ""
    
    # layout
    self.layout = GridLayout(cols=6, size_hint=(1, .05))
    self.screen.add_widget(self.layout)
    
    # buttons
    btn_editor = Button(text="EditorMode", size_hint=(2.0, 1.0))
    btn_prev = Button(text="<<", size_hint_height=.1)
    btn_next = Button(text=">>")
    btn_clear = Button(text="Clear")
    btn_exit = Button(text="Exit")
    btn_exit.bind(on_release = self.exit)
    self.layout.add_widget(btn_editor)
    self.layout.add_widget(btn_prev)
    self.layout.add_widget(btn_next)
    self.layout.add_widget(btn_clear)
    self.layout.add_widget(btn_exit) 
    
    # input text
    self.textInput = TextInput(text = "text", multiline=False, size_hint=(None, None), pos=(0,0),
      background_color=(1,1,1,0.2), foreground_color=(1,1,1,1), text_size=(0,0), font_size="14dp", padding_y="10dp")  
    self.textInput.size = (W, self.textInput.minimum_height)
    self.textInput.text = ""
    self.textInput.bind(on_text_validate = self.onConsoleInput)
    self.textInput.bind(focus = self.inputBoxFocus)
    self.screen.add_widget(self.textInput)
    self.layout.pos = (0, self.textInput.size[1])
    
    # output
    self.outputSV = ScrollView(pos = (0, self.textInput.size[1] + self.layout.size[1]), \
      size_hint=(None, None), size = (W, H - (self.textInput.size[1] + self.layout.size[1])))
    self.outputLayout = BoxLayout(orientation="vertical", size_hint_y=None)
    self.outputSV.add_widget(self.outputLayout)
    self.screen.add_widget(self.outputSV)
    
    # buttons bind
    def func_clear(inst):
      self.outputLayout.clear_widgets()
      self.outputLayout.size = (W, 0)
    btn_clear.bind(on_release = func_clear)
    
    def func_prev(inst):
      if len(self.history) > 0:
        self.historyIndex -= 1
        if self.historyIndex < 0:
          self.historyIndex = len(self.history) - 1
        self.textInput.text = self.history[self.historyIndex]
    btn_prev.bind(on_release = func_prev)
    
    def func_next(inst):
      if len(self.history) > 0:
        self.historyIndex += 1
        if self.historyIndex >= len(self.history):
          self.historyIndex = 0
        self.textInput.text = self.history[self.historyIndex]
    btn_next.bind(on_release = func_next)
    
    gMyRoot.regist(self)
    gMyRoot.setTouchPrev(self.touchPrev)
    
  def displayText(self, text):
    if type(text) != str:
      text = str(text)
    output = Label(text=text, halign='left', valign='top', readonly=True, font_size="14dp",
      multiline=True, background_color=(1,1,1,0), foreground_color=(1,1,1,1), size_hint_y=None) 
    output.size = (W, 0)
    output.text_size = (W, None)
    output.texture_update()
    output.size = output.texture_size
    # split too long text
    limitHeight = 4096
    if output.texture_size[1] > limitHeight:
      v = int(math.ceil(output.texture_size[1] / float(limitHeight)))
      if v != 0:
        # split text
        step = int(math.ceil(len(text)/float(v)))
        for i in range(0, len(text), step):
          self.displayText(text[i:i+step])
      return
    # add output widget
    self.outputLayout.size = (W, self.outputLayout.size[1] + output.texture_size[1])
    self.outputLayout.add_widget(output)
    self.outputSV.scroll_y = 0 
    
  def onConsoleInput(self, inst):
    self.lastAction = "onConsoleInput"
    if inst.text.strip():
      # pop input text from history
      if len(self.history) > 0 and self.historyIndex > -1 \
        and self.historyIndex < len(self.history) and self.history[self.historyIndex] == inst.text:
          self.history.pop(self.historyIndex)
      # append item to history
      self.history.append(inst.text)
      # check history count
      if len(self.history) > self.historyCount:
        self.history = self.history[:self.historyCount]
      self.historyIndex = len(self.history)
      # print
      if self.repl.isIndentMode:
        self.displayText(".. " + inst.text)
      else:
        self.displayText(">> " + inst.text)
    self.repl.onConsoleInput(inst.text)
    # get indent space
    self.lastIndentSpace = ""
    if self.repl.isIndentMode:
      for i in self.textInput.text:
        if i in [" ", "\t"]:
          self.lastIndentSpace += i
        else:
          break
    self.textInput.text = self.lastIndentSpace
    self.textInput.size = (W, self.textInput.minimum_height)
    self.inputBoxForceFocus(True)
  
  def inputBoxForceFocus(self, bFocus):
    if bFocus != self.textInput.focus:
      self.textInput.focus = bFocus
    
  def inputBoxFocus(self, inst, bFocus):
    if bFocus:
      offset = gMyRoot.getKeyboardHeight()
      self.textInput.pos = (0, offset)
      self.layout.pos = (0, self.textInput.size[1] + offset) 
      self.outputSV.pos = (0, self.textInput.size[1] + self.layout.size[1] + offset)
      self.outputSV.size = (W, H - (self.textInput.size[1] + self.layout.size[1] + offset))
    elif self.lastAction in ["touchPrev", "exit"]:  
      self.textInput.pos = (0, 0)
      self.layout.pos = (0, self.textInput.size[1])
      self.outputSV.pos = (0, self.textInput.size[1] + self.layout.size[1])
      self.outputSV.size = (W, H - (self.textInput.size[1] + self.layout.size[1]))
    else:
      # preserve inputmode
      self.inputBoxForceFocus(True)
    self.lastAction = "None"
    
  def update(self, dt):
    pass
    
  def touchPrev(self):
    if self.textInput.focus:
      self.lastAction = "touchPrev"
      self.inputBoxForceFocus(False)
    else:
      self.exit()
    
  def show(self):
    gMyRoot.add_screen(self.screen)
    gMyRoot.current_screen(self.screen)
  
  def exit(self, *args):
    self.lastAction = "exit"
    self.inputBoxForceFocus(False)
    def close():
      gMyRoot.setTouchPrev(None)
      gMyRoot.remove(self)
      gMyRoot.remove_screen(self.screen)
    gMyRoot.popup("Exit Python?", close, None)