import Utility as Util
from Utility import *

import PyInterpreter

if __name__ in ('__android__', '__main__'):
  py = PyInterpreter.PyInterpreter()
  py.show()
  gMyRoot.run()