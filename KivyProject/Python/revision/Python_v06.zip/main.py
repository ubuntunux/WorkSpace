import Utility as Util
from Utility import *

import PyInterpreter

if __name__ == '__main__':
  py = PyInterpreter.PyInterpreter( __name__ )
  py.show()
  #py.show()
  gMyRoot.show_debug(False)
  #gMyRoot.show_python(True)
  gMyRoot.run()