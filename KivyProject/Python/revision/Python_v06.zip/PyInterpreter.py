import Utility as Util
from Utility import *

#---------------------#
# CLASS : REPL
#---------------------#
class REPL(Singleton):
  name = "Python REPL"
  result = ""
  code = []
  lastCode = ""
  myGlobals = {}
  isIndentMode = False
  ui = None
  
  def __init__(self, ui):
    self.ui = ui
       
  def onConsoleInput(self, inputText):
    result = self.run_script(inputText)
    
    # insert result
    if result:
      self.ui.displayText(result)
    
    if self.lastCode:
      temp = self.lastCode
      self.lastCode = None
      self.onConsoleInput(temp)
      
  def run_script(self, code):
    # run script
    stripCode = code.strip()
    if self.code and (stripCode == "" or code[0] != " " and code[0] != "\t"):
      self.lastCode = code
      code = "\n".join(self.code)
      self.isIndentMode = False
      self.code = []
      
    # inner indent mode
    elif self.code or stripCode and stripCode[-1] == ":":
      self.code.append(code)
      self.isIndentMode = True
      return None
      
    try:
      self.old_stdout = sys.stdout
      self.redirected_output = sys.stdout = StringIO()
      try:
        print eval(code, self.myGlobals)
      except:
        exec(code, self.myGlobals)
        
      sys.stdout = self.old_stdout
      self.result = self.redirected_output.getvalue()
    except Exception, e:
      self.errorstring = traceback.format_exc()
      self.result = ("ERROR: " + self.errorstring)
    return self.result[:-1]

#---------------------#
# CLASS : PyInterpreter
#---------------------#    
class PyInterpreter(Singleton):
  def __init__(self, host = ""):
    self.isMain = host == '__main__'
    self.screen = Screen(name="MainScreen")
    self.repl = REPL(self)
    self.history = ["",]
    self.historyIndex = -1
    self.historyCount = 100
    self.lastIndentSpace = ""
    self.defaultFont = kivy.resources.resource_find(os.path.join("fonts","DroidSansMonoDotted.ttf"))
    self.bIndentMode = False
    self.reFocusInputText = False
    # layout
    self.layout = GridLayout(cols=6, size_hint=(1, None), height="30dp")
    self.screen.add_widget(self.layout)
    
    # buttons
    btn_run = Button(text="Run Script", size_hint=(2.0, 1.0))
    btn_run.bind(on_release = self.runCode)
    btn_prev = Button(text="<<")
    btn_next = Button(text=">>")
    btn_clear = Button(text="Clear")
    btn_exit = Button(text="Exit")
    btn_exit.bind(on_release = self.exit)
    self.layout.add_widget(btn_run)
    self.layout.add_widget(btn_prev)
    self.layout.add_widget(btn_next)
    self.layout.add_widget(btn_clear)
    self.layout.add_widget(btn_exit) 

    self.textInput = TextInput(text = "text", multiline=False, size_hint=(None, None), font_name=self.defaultFont, auto_indent = True,
      background_color=(1,1,1,0.2), foreground_color=(1,1,1,1), text_size=(0,0), font_size="14dp", padding_y="10dp")  
    self.textInput.size = (W, self.textInput.minimum_height)
    self.textInput.text = ""
    self.textInput.bind(on_text_validate = self.onConsoleInput)
    self.textInput.bind(focus = self.inputBoxFocus)
    # bind paste
    def paste():
      self.insertInputText(gMyRoot.getClipboard())
    self.textInput.paste = paste
    # add input widget
    self.screen.add_widget(self.textInput)
    
    # output
    self.outputSV = ScrollView(size_hint=(None, None))
    self.outputLayout = BoxLayout(orientation="vertical", size_hint_y=None)
    self.outputSV.add_widget(self.outputLayout)
    self.screen.add_widget(self.outputSV)
    
    # buttons bind
    def func_clear(inst):
      self.outputLayout.clear_widgets()
      self.outputLayout.size = (W, 0)
    btn_clear.bind(on_release = func_clear)
    
    def func_prev(inst):         
      if len(self.history) > 0:
        self.historyIndex -= 1
        if self.historyIndex < 0:
          self.historyIndex = len(self.history) - 1
        text = self.history[self.historyIndex]
        if text.find("\n") > -1:
          self.bIndentMode = True
        self.setInputText(text)
    btn_prev.bind(on_release = func_prev)
    
    def func_next(inst):
      if len(self.history) > 0:
        self.historyIndex += 1
        if self.historyIndex >= len(self.history):
          self.historyIndex = 0
        text = self.history[self.historyIndex]
        if text.find("\n") > -1:
          self.bIndentMode = True
        self.setInputText(text)
    btn_next.bind(on_release = func_next)
    
    self.displayText("Python " + sys.version)
    self.refreshLayout()
    gMyRoot.setTouchPrev(self.touchPrev)
    gMyRoot.regist(self)
    
  def displayText(self, text):
    if type(text) != str:
      text = str(text)
       
    output = TextInput(text="", halign='left', valign='top', readonly=True, font_size="12dp", font_name = self.defaultFont,
      multiline=True, background_color=(1,1,1,0), foreground_color=(1,1,1,1), size_hint_y=None, size = (W, 0))
    output.text = text
    output.size = (W, output.minimum_height)
    
    self.outputLayout.add_widget(output)
    self.outputLayout.size = (W, self.outputLayout.size[1] + output.size[1])
    self.outputSV.scroll_y = 0 
  
  def runCode(self, inst):
    self.onConsoleInput(self.textInput, True)
    
  def onConsoleInput(self, inst, bForceRun = False):
    self.reFocusInputText = True
    if inst.text.strip():
      bRunCode = len(inst.text) == self.textInput.cursor_index()
      lastLine_nonStrip = inst.text.split("\n")[-1]
      lastLine = lastLine_nonStrip.strip()
      # indent mode - continue input but not run
      if not bForceRun and lastLine and (lastLine[-1] == ":" or self.bIndentMode or not bRunCode):
        self.bIndentMode = True
        # get indent space
        self.lastIndentSpace = ""
        if self.bIndentMode:
          for i in lastLine_nonStrip:
            if i in [" ", "\t"]:
              self.lastIndentSpace += i
            else:
              break
        inst.insert_text("\n" + self.lastIndentSpace)
        self.textInput.size = (W, self.textInput.minimum_height)
        return
      # check indent mode - run code
      self.bIndentMode = False
      # pop input text from history
      if len(self.history) > 0 and self.historyIndex > -1 \
        and self.historyIndex < len(self.history) and self.history[self.historyIndex] == inst.text:
          self.history.pop(self.historyIndex)
      # append item to history
      self.history.append(inst.text.strip())
      # check history count
      if len(self.history) > self.historyCount:
        self.history = self.history[:self.historyCount]
      self.historyIndex = len(self.history)
      # display input text to output widget
      lines = inst.text.split("\n")
      result = []
      for i, line in enumerate(lines):
        line = (">> " if i == 0 else ".. ") + line
        result.append(line)
      result = "\n".join(result)
      self.displayText(result)
      # run code
      self.repl.onConsoleInput(inst.text)
      self.setInputText("")
      
  def refreshLayout(self, offset = 0):
    topMargin = kivy.metrics.dp(30)
    self.textInput.pos = (0, offset)
    limitHeight = (H - offset - topMargin) * 0.5
    if self.textInput.minimum_height > limitHeight:
      height = limitHeight
    else:
      height = self.textInput.minimum_height
    self.textInput.size = (W, height)
    self.layout.pos = (0, self.textInput.size[1] + offset) 
    self.outputSV.pos = (0, self.textInput.size[1] + self.layout.size[1] + offset)
    self.outputSV.size = (W, H - (topMargin + self.textInput.size[1] + self.layout.size[1] + offset))
  
  def setInputText(self, text):
    self.textInput.text = text
    if self.textInput.size[1] != self.textInput.minimum_height:
      self.refreshLayout(gMyRoot.getKeyboardHeight() if self.textInput.focus else 0)
  
  def insertInputText(self, text):
    self.textInput.insert_text(text)
    if self.textInput.size[1] != self.textInput.minimum_height:
      self.refreshLayout(gMyRoot.getKeyboardHeight() if self.textInput.focus else 0)
  
  def inputBoxForceFocus(self, bFocus):
    if bFocus != self.textInput.focus:
      self.textInput.focus = bFocus 
      
  def inputBoxFocus(self, inst, bFocus):
    if bFocus:
      self.refreshLayout(gMyRoot.getKeyboardHeight())
    else:
      self.refreshLayout()
      if self.reFocusInputText:
        self.reFocusInputText = False
        self.textInput.focus = True
    self.reFocusInputText = False
    
  def update(self, dt):
    pass
    
  def touchPrev(self):
    if self.textInput.focus:
      self.reFocusInputText = False
      self.inputBoxForceFocus(False)
    else:
      self.exit()
    
  def show(self):
    gMyRoot.add_screen(self.screen)
    gMyRoot.current_screen(self.screen)
  
  def exit(self, *args):
    self.reFocusInputText = False
    self.inputBoxForceFocus(False)
    def close():
      gMyRoot.setTouchPrev(None)
      gMyRoot.remove(self)
      gMyRoot.remove_screen(self.screen)
      if self.isMain:
        gMyRoot.exit()
    gMyRoot.popup("Exit Python?", close, None)