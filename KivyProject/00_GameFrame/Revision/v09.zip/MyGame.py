import Utility as Util
from Utility import *
import gc
from Particle import *
from ResourceMgr import *

gMyRoot = Util.MyRoot.instance()
gDebug = Util.DebugPrint.instance()
gFxMgr = FxMgr.instance()
gResMgr = ResourceMgr.instance()

gPlayer = None
gCheckAngle = 0.707
gFriction = 10.0
gMaxSpeed = 60.0
gGround = Util.H * 0.05
gJump = Util.H * 1.8
gVel = Util.W * 0.8
gWalk = Util.W * 0.3
gIncVel = Util.W * 1.6
gDecVel = Util.W * 2.5
gRange = Util.W * 0.3
gUnitSize = [Util.H*.18]*2
gCenter = mul(Util.WH, 0.5)
gWorldSize = mul(Util.WH, (1.0, 1.0))
gGravity = H * 5.5

#---------------------#
# CLASS : MyGameStateMgr
#---------------------#
class MyGame_Mgr(StateMachine, Singleton): 
  def __init__(self):
    self.running = False
    self.onExitFunc = None
    self.addState(MyGame_Start)
    self.addState(MyGame_Exit)
  
  def bind_OnExitFunc(self, func):
    self.onExitFunc = func

  def run(self):
    if self.running:
      return
    self.running = True
    gMyRoot.regist(self)
    self.setState(MyGame_Start)

  def onTouchPrev(self):
    self.running = False
    gMyRoot.remove(self)
    self.setState(MyGame_Exit)
    if self.onExitFunc:
      self.onExitFunc()

# MYGAME_START
class MyGame_Start(Screen, StateItem):      
  def __init__(self):
    Screen.__init__(self, name="MyGame")
    # add bg
    self.layer_bg = Widget()
    with self.layer_bg.canvas:
      Rectangle(texture=gResMgr.getTex('bg01'), size=gWorldSize)
    self.add_widget(self.layer_bg)
    
    # add star
    self.star = Scatter(source=gResMgr.getImg('star'), pos=(0,0), size=(200,200))
    with self.star.canvas:
      Rectangle(texture=gResMgr.getTex('star'),size=self.star.size)
    self.star.bind(on_touch_up=self.setFx)
    self.layer_bg.add_widget(self.star)

    # add particle manager
    self.layer_fx = Widget()
    gFxMgr.setLayer(self.layer_fx)
    self.add_widget(self.layer_fx)
    
    # add ui layer
    self.layer_ui = Widget()
    btn = Button(text='exit', center=Util.cXY)
    btn.bind(on_release=lambda x:self.stateMgr.onTouchPrev())
    self.layer_ui.add_widget(btn)
    self.add_widget(self.layer_ui)
    
  def preLoadFx(self):
    particleInfo = dict(loop=-1,texture=gResMgr.getTex('explosion'), fade=1, delay=Var(0.0,1.0),
      lifeTime=Var(0.5,1.5),sequence=[4,4], vel=Var([gVel*0.1, gJump*0.1], [-gVel*0.1, gJump*0.25]), scale=Var(1.0, 2.5))
    gFxMgr.create_emitter('explosion', particleInfo, 10)
    
  def setFx(self, a, b):
    if b.grab_current is not self.star:
      return
    emitter = gFxMgr.get_emitter('explosion')
    emitter.center = self.star.center
    emitter.play_particle()
     
  def onEnter(self):
    self.preLoadFx()
    gMyRoot.add_screen(self)
    gMyRoot.current_screen(self)
  
  def onUpdate(self):
    gFxMgr.onUpdate()
    
  def onExit(self):
    gFxMgr.remove_emitter()
    gMyRoot.remove_screen(self)

# MYGAME_EXIT
class MyGame_Exit(StateItem):
  pass