from GameFrame import *
from StateMachine import *
from Resource import *

STATE_NONE = 0
STATE_MENU = 1
STATE_PLAY = 2

#---------------------#
# CLASS : StateMgr
#---------------------#
class StateMgr(StateMachine):	
	def __init__(self):
		self.addState(StateNone()) # STATE_NONE
		self.addState(StateMenu()) # STATE_MENU
		self.addState(StatePlay()) # STATE_PLAY
		
		self.setState(STATE_NONE)

# STATE_NONE
class StateNone(StateItem):
	def onUpdate(self):
		self.stateMgr.setState(STATE_MENU)

# STATE_MENU
class StateMenu(Widget, StateItem):
	def __init__(self):
		super(StateMenu,self).__init__()
		with self.canvas:
			Color(0.2,0.2,0.2)
			Rectangle(source = szMenu_BG, size = (Util.W, Util.H))
		self.btn_start = getButton("Start", (0.5, 0.7), (0.3, 0.05))
		self.btn_exit = getButton('Exit', (0.5, 0.6), (0.3, 0.05))
		self.btn_start.bind(on_release = self.setPlay)
		self.btn_exit.bind(on_release = self.callback_Exit)
		self.add_widget(self.btn_start)
		self.add_widget(self.btn_exit)
		
	def callback_Exit(self, inst):
		getGameApp().popup_Exit()
		
	def setPlay(self, inst):
		self.stateMgr.setState(STATE_PLAY)
		
	def onEnter(self):
		getGameRoot().add_widget(self)
		getGameApp().resetTouchPrev()
	
	def onExit(self):
		getGameRoot().remove_widget(self)

# STATE_PLAY
class StatePlay(Widget, StateItem):
	def __init__(self):
		super(StatePlay,self).__init__()
		with self.canvas:
			Color(.5,.5,.5)
			Rectangle(size=Util.WH)
			
		self.btn_exit = getButton('Exit', (0.5, 0.7), (0.3, 0.05))
		self.btn_exit.bind(on_release = self.callback_Exit)
		self.add_widget(self.btn_exit)
		
	def callback_Exit(self, inst):
		self.stateMgr.setState(STATE_MENU)
	
	def callback_Prev(self):
		self.stateMgr.setState(STATE_MENU)
		
	def onEnter(self):		
		getGameRoot().add_widget(self)
		getGameApp().setTouchPrev(self.callback_Prev)
		
	def onExit(self):
		getGameRoot().remove_widget(self)
		
if __name__ in ('__android__', '__main__'):
	Util.startPoint = StateMgr()
	GameApp().run()