import Utility as Util
from Utility import *
import math
from kivy.graphics import Scale, Rotate, PushMatrix, PopMatrix, Translate, \
                          UpdateNormalMatrix

class Sprite(Widget):
  def __init__(self, pos=cXY, size=(100.0, 100.0), **kargs):
    Widget.__init__(self, pos=pos, size=size)
    self.box = None
    self.boxPos = None
    self.boxRot = None
    self.boxScale = None
    self.source = None
    self.texture = None
    self.collision = False
    self.elastin = 0.8
    self.gravity = 0.0
    self.vel = [0.0, 0.0]
    self.rotate = 0.0
    self.rotateVel = 0.0
    self.scaling = 1.0
    self.opacity = 1.0
    self.offset = (0.0, 0.0)
    self.realSize = (0,0)
    self.isGround = False
    
    # set argment
    for key in kargs:
      if not hasattr(self, key):
        raise AttributeError(self.__class__.__name__ + " not found " + key)
      setattr(self, key, kargs[key])
    # if vel is maybe tuple, convert to list
    self.vel = list(self.vel)
      
    # clamp
    self.elastin = max(min(self.elastin, 1.0), 0.0)
    
    if self.source != None:
      self.texture = self.source.texture
              
    if self.texture:
      with self.canvas:
        Color(1,1,1,1)
        self.box = Rectangle(texture=self.texture, pos=(0,0), size=self.size)
      with self.canvas.before:
        PushMatrix()
        self.boxPos = Translate(0,0)
        self.boxRot = Rotate(angle=0, axis=(0,0,1), origin=mul(mul(self.size, 0.5), self.scaling))
        self.boxScale = Scale(1,1,1)
      with self.canvas.after:
        PopMatrix()
        
    self.boxPos.x = self.pos[0] + (-self.size[0] * 0.5) + self.offset[0]
    self.boxPos.y = self.pos[1] + (-self.size[1] * 0.5) + self.offset[1]
    self.pos = (0,0)
    self.boxRot.origin = mul(mul(self.size, 0.5), self.scaling)
    self.boxRot.angle = self.rotate
    self.boxScale.xyz = (self.scaling, self.scaling, self.scaling) 
    self.realSize = mul(self.size, self.scaling)
    
    Clock.schedule_interval(self.update, 0)
    
  def getPos(self):
    return (self.boxPos.x, self.boxPos.y)
      
  def setPos(self, pos):
    self.boxPos.x = pos[0]
    self.boxPos.y = pos[1]
    
  def getVelocity(self):
    return self.vel
    
  def setVelocity(self, vel):
    self.vel = list(vel)
    
  def getRotate(self):
    return self.boxRot.angle
    
  def setRotate(self, angle):
    self.boxRot.angle = angle
    
  def getRotateVel(self):
    return self.rotateVel
    
  def setRotateVel(self, vel):
    self.rotateVel = vel
    
  def getScale(self):
    return self.scaling
    
  def setScale(self, scale):
    self.scaling = scale
    self.realSize = mul(self.size, self.scaling)
    self.boxScale.xyz = (scale, scale, scale)

  def update(self, fFrameTime):
    # set gravity
    if self.gravity != 0 and not self.isGround:
      self.vel[1] -= self.gravity * fFrameTime
    
    # adjust velocity, move
    if self.vel[0] != 0:
      self.boxPos.x += self.vel[0] * fFrameTime
    if self.vel[1] != 0:
      self.boxPos.y += self.vel[1] * fFrameTime
    
    if self.collision:
      if self.boxPos.x < 0.0:
        self.boxPos.x = -self.boxPos.x
        self.vel[0] = -self.vel[0] * self.elastin
      elif self.boxPos.x > Util.W - self.realSize[0]:
        self.boxPos.x = (Util.W - self.realSize[0]) * 2.0 - self.boxPos.x
        self.vel[0] = -self.vel[0] * self.elastin
      if self.boxPos.y < 0.0:
        self.boxPos.y = -self.boxPos.y
        self.vel[1] = -self.vel[1] * self.elastin 
      elif self.boxPos.y > Util.H - self.realSize[1]:
        self.boxPos.y = (Util.H - self.realSize[1]) * 2.0 - self.boxPos.y
        self.vel[1] = -self.vel[1] * self.elastin
      
    if self.rotateVel != 0.0:
      self.boxRot.angle += self.rotateVel * fFrameTime