import Utility as Util
from Utility import *

STATE_ENTER = 0
STATE_START = 1
STATE_EXIT = 2
szDebug = 'none'

#---------------------#
# CLASS : StateMgr
#---------------------#
class State_Mgr(StateMachine):	
	def __init__(self):
		self.addState(State_Enter()) # STATE_ENTER
		self.addState(State_Start()) # STATE_START
		self.addState(State_Exit()) # STATE_EXIT
		self.setState(STATE_ENTER)
	
# STATE_ENTER
class State_Enter(StateItem):
	def onUpdate(self):
		self.setState(STATE_START)

# STATE_START
class State_Start(Widget, StateItem):
	def callback_Exit(self, inst = None):
		getMyApp().popup_Exit()

	def onEnter(self):
		getMyRoot().add_widget(self)
		getMyApp().setTouchPrev(self.callback_Exit)
		self.btn_Exit = Button(text='Exit')
		self.add_widget(self.btn_Exit)
		def Press_Exit(inst):
			self.setState(STATE_EXIT)
		self.btn_Exit.bind(on_release = Press_Exit)

# STATE_EXIT
class State_Exit(StateItem):
	def onEnter(self):
		getMyApp().stop()

if __name__ in ('__android__', '__main__'):
	Util.MyApp().start( State_Mgr() )