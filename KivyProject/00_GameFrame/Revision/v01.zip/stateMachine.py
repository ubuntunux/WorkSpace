#---------------------#
# CLASS : StateItem
#---------------------#
class StateItem():	
	stateMgr = None
	
	def onEnter(self):
		pass
		
	def onUpdate(self):
		pass
		
	def onExit(self):
		pass
	
#---------------------#
# CLASS : StateMachine
#---------------------#
class StateMachine(object):
	stateCount = 0
	stateList = []
	curState = -1
	oldState = -1
		
	def addState(self, stateItem):
		self.stateCount += 1
		self.stateList.append(stateItem)
		stateItem.stateMgr = self
	
	def getCount(self):
		return self.stateCount
		
	def isState(self, index):
		return index == self.curState
		
	def getState(self):
		return self.curState
	
	def setState(self, index):
		if index < self.stateCount and index != self.curState:
			self.oldState = self.curState
			self.curState = index
			if self.oldState > 0:
				self.stateList[self.oldState].onExit()
			if index > 0:
				self.stateList[index].onEnter()

	def update(self):
		if self.stateList:
			self.stateList[self.curState].onUpdate()