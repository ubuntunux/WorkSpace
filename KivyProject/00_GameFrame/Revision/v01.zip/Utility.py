#---------------------#
# Import kivy
#---------------------#
import kivy
from kivy.app import App
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.core.audio import SoundLoader
from kivy.factory import Factory
from kivy.graphics import Color, Rectangle, Point, GraphicException, Line, Quad, Ellipse, Fbo, RenderContext
from kivy.graphics.opengl import glLineWidth
from kivy.logger import Logger
from kivy.properties import NumericProperty, ReferenceListProperty, ObjectProperty, StringProperty
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.image import Image
from kivy.uix.label import Label
from kivy.uix.popup import Popup
from kivy.uix.scatter import Scatter
from kivy.uix.slider import Slider
from kivy.uix.widget import Widget
from kivy.vector import Vector

#---------------------#
# Import library
#---------------------#
import android
from cmath import polar, rect
from copy import deepcopy
from glob import glob
from math import cos,sin,pi,sqrt,atan,atan2
import os
import random
import sys

from MultiMethod import multimethod

#---------------------#
# Global variable
#---------------------#
startPoint = None
W = Window.size[0]
H = Window.size[1]
WH = (W, H)
cX = W * 0.5
cY = H * 0.5
cXY = (W * 0.5, H * 0.5)
fUpdateTime = 1.0 / 60.0
fFrameTime = 1.0
fGameTime = 0.0
bButtonLock = False
gGameApp = None
gGameRoot = None
gDebugPrint = None

def getFrameTime():
	return fFrameTime
	
def getGameTime():
	return fGameTime

def getDebugPrint():
	return gDebugPrint
	
def getGameRoot():
	return gGameRoot

def getGameApp():
	return gGameApp

def sizeHint(ratioX, ratioY):
	return (W * ratioX, H * ratioY)
	
#---------------------#
# Utility
#---------------------#
def nRand(min, max):
	return random.randint(min, max)

def fRand(min, max):
	return random.uniform(min, max)

def calcCenterPos(pos, size):
	return (pos[0]+size[0]/2.0, center_pos[1]+size[1]/2.0)
	 	
def calcPos(center_pos, size):
	return (center_pos[0]-size[0]/2.0, center_pos[1]-size[1]/2.0)

def calcSize(size, ratioX, ratioY):
	return (size[0]*ratioX, size[1]*ratioY)

def getButton(text, center, size):
	widget = Button()
	widget.text = text
	widget.size = sizeHint( size[0], size[1] )
	widget.center = sizeHint( center[0], center[1] )
	return widget

#---------------------#
# CLASS : DebugPrint
#---------------------#
class DebugPrint(Widget):
	nLine = 0
	nLineLimit = 85
	bShowFrame = True
	debugLabel = Label(text = "debug print text", halign = 'left', valign = 'top')
	
	def __init__(self):
		gDebugPrint = self
		super(DebugPrint, self).__init__()
		self.nLine = 0
		self.size = (W,H)
		self.debugLabel.x = W - self.debugLabel.width
		self.debugLabel.y = H - self.debugLabel.height
		self.add_widget(self.debugLabel)
		
	def showFrame(self, bShow):
		self.bShowFrame = bShow
	
	def Print(self, szString):
		if self.nLine > self.nLineLimit:
			return False
		self.nLine += 1
		if self.debugLabel.text:
			self.debugLabel.text += "\n"
		self.debugLabel.text += szString
		return True
		
	def Printf(self, fNum):
		if self.nLine > self.nLineLimit:
			return False
		self.nLine += 1
		if self.debugLabel.text:
			self.debugLabel.text += "\n"
		self.debugLabel.text += str(fNum)
		return True
	
	def showProp(self, obj, start = 0):
		for x,i in enumerate(dir(obj)[start:-1]):
			if self.Print(str(x+start)+'.'+i) == False:
				return
	
	def Reset(self):
		self.nLine = 0
		if self.bShowFrame:
			self.debugLabel.text = "%.2f" % (1.0/fFrameTime)
		else:
			self.debugLabel.text = ""

#---------------------#
# Method
#---------------------#
overload = multimethod

@overload()	
def getX():
	return cX
	
@overload(int)	
def getX(a):
	return cX*a

@overload(int, int)
def getX(a,b):
	return cX*b

