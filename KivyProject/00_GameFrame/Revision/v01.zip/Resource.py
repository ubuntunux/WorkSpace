import os

szImagePath = 'Image'
szMenu_BG = os.path.join(szImagePath, 'Menu_BG.jpg')
szEnemy = os.path.join(szImagePath, 'asteroid2-deco.png')