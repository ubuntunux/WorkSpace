import Utility as Util
from Utility import *

STATE_NONE = 0
STATE_START = 1

#---------------------#
# CLASS : StateMgr
#---------------------#
class State_Mgr(StateMachine):	
	def __init__(self, is_main):
		self.is_main = is_main
		if is_main:
			Util.startPoint = self
		else:
			Util.add_App(self)
			
		self.addState(State_None()) # STATE_NONE
		self.addState(State_Start()) # STATE_START
		self.setState(STATE_NONE)

# STATE_NONE
class State_None(StateItem):
	def onUpdate(self):
		self.stateMgr.setState(STATE_START)

# STATE_START
class State_Start(Widget, StateItem):
	def callback_Exit(self, inst = None):
		if self.stateMgr.is_main == True:
			getMyApp().popup_Exit()
		else:
			getMyRoot().remove_widget(self)
			remove_App(self)

	def onEnter(self):
		getMyRoot().add_widget(self)
		getMyApp().setTouchPrev(self.callback_Exit)
		
if __name__ in ('__android__', '__main__'):
	State_Mgr(True)
	MyApp().run()