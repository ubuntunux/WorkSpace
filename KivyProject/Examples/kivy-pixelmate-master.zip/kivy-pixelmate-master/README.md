kivy-pixelmate
==============
kivy contest 2014 entry

PixelMate is a graphical pixel art editor for android devices and PC. The program is at a very early stage of development, the source code has not yet been refactoring, so if you value your nerves don't try to read it:)


Requirements

    Python 2.7
    Kivy 1.80
    PIL 1.1.7

    
Installation and running

    See guides at http://kivy.org/docs/gettingstarted/installation.html
    For running on android devise use the kivy launcher app from GooglePlay

    
Packaging for device

    See guides at http://kivy.org/docs/gettingstarted/packaging.html

    
Used tools

    PyCharm Community Edition 3
    GIMP 2
        
        
License

    GPL 2

TIPS

    Use the long tap on the color cell to open a color selection dialog
    Use the long tap on the layer to drag and replace layers
